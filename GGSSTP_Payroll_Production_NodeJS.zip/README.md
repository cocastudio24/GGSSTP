# GGSSTP — Guru Gobind Singh Super Thermal Plant, Rupnagar
## Contractual Employee Payroll Management System

A production-grade, secure, web-based salary and payroll management system engineered specifically for managing contractual employees under various service providers and plant operational circles at **Guru Gobind Singh Super Thermal Plant (GGSSTP), Rupnagar, Punjab, India**.

---

## 1. Key Features

- **Reference-Compatible Payroll Engine**: 100.0% mathematical reproduction of plant calculations from reference workbook `SALARY SHEET-for EPF Sepf 2026.xlsx` across both `MM-1` and `EMC` circles.
- **Formula-Preserving Excel Exports**: Generates genuine Microsoft Excel workbooks (`.xlsx`) containing live Excel formulas (`=ROUND(...)`, `=SUM(...)`, `=IF(...)`), auto-filter, and rate cards.
- **Multi-Layout Excel Import Center**: Automatically detects `MM-1`, `EMC`, and standard vertical tabular layouts, validates biographical and banking data, resolves external lookups, and provides pre-commit diff preview.
- **Comprehensive Employee Master**: Full CRUD, bank account and UAN masking, contractor assignments, circle and cell routing, qualification and tenure tracking, and soft deletion.
- **Workflow State Progression**: Governs the monthly lifecycle (`Draft` → `Calculated` → `Under Review` → `Approved` → `Finalized`) with role-based authorizations and revision locking.
- **Formula Audit & Live Reconciliation**: Built-in verification engine comparing calculated results against original Excel reference rows with 100% precision.
- **Enterprise Security & Audit Trail**: Role-based access control (Super Admin, Payroll Admin, Operator, Auditor), bcrypt password hashing, JWT sessions, and full operational audit logs.
- **Zero-Config Persistent Storage**: Embedded PostgreSQL persistence (PGlite) for instant local execution, plus ready-to-deploy standard PostgreSQL migration scripts and Docker Compose.

---

## 2. Technology Stack

- **Frontend**: React 18, TypeScript, Vite, Lucide Icons, responsive enterprise design.
- **Backend**: Node.js v20+, Express 5, TypeScript.
- **Database**:
  - Development / Zero-Dependency Local Mode: Persistent PostgreSQL engine via `@electric-sql/pglite`.
  - Cloud / Production Mode: PostgreSQL 16+ via connection string `DATABASE_URL`.
- **Excel Engine**: ExcelJS (live formulas and styling) & SheetJS (multi-sheet inspection).
- **Security**: JWT tokens, bcryptjs, role-based authorization middleware.

---

## 3. Quickstart (Local Runnable Version)

### Prerequisites
- Node.js (v18 or higher) and npm installed.

### Step 1: Install Dependencies
```bash
# Root dependencies
npm install

# Client dependencies
cd client && npm install && cd ..
```

### Step 2: Build the Application
```bash
npm run build
```

### Step 3: Run the Automated Test Suite
```bash
npm test
```
*Executes all 36 unit, formula precision, boundary condition, and Excel export tests.*

### Step 4: Start the Server
```bash
npm start
```
*The unified web application will start at:* **`http://localhost:5000`**

---

## 4. Default Seeded Credentials

The database is automatically initialized with 4 pre-configured role accounts:

| Role | Username | Password | Access Privileges |
| :--- | :--- | :--- | :--- |
| **Super Administrator** | `admin` | `admin@ggsstp2026` | Full administrative control, user creation, reopen finalized payroll, backup restore |
| **Payroll Administrator**| `payroll_admin` | `payroll@ggsstp2026` | Employee CRUD, attendance processing, rate updates, payroll approval |
| **Payroll Operator** | `operator` | `operator@ggsstp2026` | Attendance updates, data entry, monthly draft preparation |
| **Approver / Auditor** | `auditor` | `auditor@ggsstp2026` | Review calculations, reconciliation reports, approve/audit runs |

---

## 5. Reference Salary Rates (September 2026)

| Designation Alias | Full Designation Name | Gross Salary Rate | Special Allowance | Thermal Allowance (Prorated) | Perf. Allowance Default |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **USW** | Unskilled | ₹14,408 | ₹3,314 | ₹1,500 | ₹225 |
| **SEMI SW** | Semi Skilled | ₹15,395 | ₹3,541 | ₹1,500 | ₹225 |
| **SW** | Skilled | ₹16,530 | ₹3,802 | ₹1,500 | ₹225 |
| **HSW** | Highly Skilled | ₹17,835 | ₹4,102 | ₹1,500 | ₹225 |

---

## 6. Production Deployment Instructions

### Option A: Docker Compose (Recommended for Plant On-Premise Servers)

1. Clone or copy the project repository to your Linux or Windows server.
2. Ensure Docker and Docker Compose are installed.
3. Start the entire application and dedicated PostgreSQL database:
   ```bash
   docker-compose up -d --build
   ```
4. Access the web portal at `http://<server-ip>:5000`.

### Option B: Cloud Database Deployment (Supabase / Neon / AWS RDS)

1. Set up a PostgreSQL instance on your cloud provider.
2. Configure your environment variables in `.env`:
   ```env
   PORT=5000
   NODE_ENV=production
   JWT_SECRET=your-secure-jwt-secret
   DATABASE_URL=postgresql://user:password@cloud-host:5432/ggsstp_payroll
   ```
3. Run migrations and start the server:
   ```bash
   npm run build
   npm start
   ```

---

## 7. Database Backup & Disaster Recovery

### Creating a Backup
1. Navigate to **Settings & Backups** in the navigation bar.
2. Click **Export Complete System Backup (.json)**.
3. A JSON snapshot containing all employee records, salary rates, historical payroll snapshots, overrides, and audit logs will download immediately.

### Restoring a Backup
1. In **Settings & Backups**, click **Restore Backup JSON** and select the snapshot file.
2. The system verifies and imports the records with complete audit logging.

---

## 8. Verification & Formula Audit Report

See [`FORMULA_AUDIT_REPORT.md`](file:///d:/GGSSTP/FORMULA_AUDIT_REPORT.md) for full line-by-line mathematical specifications, external lookup handling, and reconciliation results.
