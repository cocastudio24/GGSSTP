import React, { useState, useEffect } from 'react';
import { User, PayrollPeriod, Designation, Contractor, Circle, DashboardStats } from './types';
import { apiRequest, getToken, clearToken } from './api';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { EmployeeView } from './components/EmployeeView';
import { PayrollView } from './components/PayrollView';
import { DesignationView } from './components/DesignationView';
import { ContractorView } from './components/ContractorView';
import { ImportView } from './components/ImportView';
import { ExportView } from './components/ExportView';
import { ReconciliationView } from './components/ReconciliationView';
import { UserView } from './components/UserView';
import { AuditLogView } from './components/AuditLogView';
import { SettingsView } from './components/SettingsView';
import { FormulaRulesView } from './components/FormulaRulesView';
import { LoginModal } from './components/LoginModal';

export const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [currentTab, setCurrentTab] = useState('dashboard');

  // Global plant telemetry data
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [selectedPeriodId, setSelectedPeriodId] = useState<number | null>(null);
  const [designations, setDesignations] = useState<Designation[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [circles, setCircles] = useState<Circle[]>([]);
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(false);

  // Check auth session
  const checkAuth = async () => {
    const token = getToken();
    if (!token) {
      setCheckingAuth(false);
      return;
    }
    try {
      const res = await apiRequest<{ user: User }>('/auth/me');
      setUser(res.user);
    } catch {
      clearToken();
      setUser(null);
    } finally {
      setCheckingAuth(false);
    }
  };

  useEffect(() => {
    checkAuth();
    window.addEventListener('auth:unauthorized', () => setUser(null));
  }, []);

  // Fetch initial master lists
  const fetchMasterData = async () => {
    if (!user) return;
    try {
      const [pRes, dRes, cRes, cirRes] = await Promise.all([
        apiRequest<{ periods: PayrollPeriod[] }>('/payroll/periods'),
        apiRequest<{ designations: Designation[] }>('/designations'),
        apiRequest<{ contractors: Contractor[] }>('/org/contractors'),
        apiRequest<{ circles: Circle[] }>('/org/circles')
      ]);

      setPeriods(pRes.periods);
      if (pRes.periods.length > 0 && !selectedPeriodId) {
        setSelectedPeriodId(pRes.periods[0].id);
      }
      setDesignations(dRes.designations);
      setContractors(cRes.contractors);
      setCircles(cirRes.circles);
    } catch (err: any) {
      console.error('Error fetching master data:', err);
    }
  };

  // Fetch dashboard stats whenever selected period changes
  const fetchDashboardStats = async () => {
    if (!user) return;
    try {
      setLoadingDashboard(true);
      const url = selectedPeriodId ? `/dashboard/stats?periodId=${selectedPeriodId}` : '/dashboard/stats';
      const res = await apiRequest<DashboardStats>(url);
      setDashboardStats(res);
    } catch (err: any) {
      console.error('Error fetching dashboard stats:', err);
    } finally {
      setLoadingDashboard(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchMasterData();
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchDashboardStats();
    }
  }, [user, selectedPeriodId]);

  const handleLogout = () => {
    clearToken();
    setUser(null);
  };

  if (checkingAuth) {
    return (
      <div style={{ display: 'flex', height: '100vh', justifyContent: 'center', alignItems: 'center', background: '#0f172a', color: '#ffffff' }}>
        <div>Connecting to GGSSTP Thermal Plant Portal...</div>
      </div>
    );
  }

  if (!user) {
    return <LoginModal onSuccess={(u) => setUser(u)} />;
  }

  const activePeriod = periods.find(p => p.id === selectedPeriodId) || periods[0] || null;

  return (
    <div className="app-container">
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userRole={user.role}
      />

      <div className="main-content">
        <TopBar
          user={user}
          onLogout={handleLogout}
          periods={periods}
          selectedPeriodId={selectedPeriodId}
          onSelectPeriod={(id) => setSelectedPeriodId(id)}
          onPeriodCreated={async (id) => {
            setSelectedPeriodId(id);
            await fetchMasterData();
            await fetchDashboardStats();
          }}
        />

        <main className="view-body">
          {currentTab === 'dashboard' && (
            <DashboardView
              stats={dashboardStats}
              loading={loadingDashboard}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'employees' && (
            <EmployeeView
              designations={designations}
              contractors={contractors}
              circles={circles}
            />
          )}

          {currentTab === 'payroll' && (
            <PayrollView
              period={activePeriod}
              periods={periods}
              onSelectPeriod={(id) => setSelectedPeriodId(id)}
              onRefreshPeriod={() => {
                fetchMasterData();
                fetchDashboardStats();
              }}
              onPeriodCreated={async (id) => {
                setSelectedPeriodId(id);
                await fetchMasterData();
                await fetchDashboardStats();
              }}
              designations={designations}
              contractors={contractors}
              userRole={user.role}
            />
          )}

          {currentTab === 'formula-rules' && (
            <FormulaRulesView
              onRefreshAll={fetchMasterData}
            />
          )}

          {currentTab === 'designations' && (
            <DesignationView
              designations={designations}
              onRefresh={fetchMasterData}
              userRole={user.role}
            />
          )}

          {currentTab === 'contractors' && (
            <ContractorView
              contractors={contractors}
              circles={circles}
              onRefresh={fetchMasterData}
            />
          )}

          {currentTab === 'import' && (
            <ImportView
              onRefreshAll={() => {
                fetchMasterData();
                fetchDashboardStats();
              }}
            />
          )}

          {currentTab === 'export' && (
            <ExportView
              period={activePeriod}
            />
          )}

          {currentTab === 'reconciliation' && (
            <ReconciliationView />
          )}

          {currentTab === 'users' && (
            <UserView />
          )}

          {currentTab === 'audit' && (
            <AuditLogView />
          )}

          {currentTab === 'settings' && (
            <SettingsView />
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
