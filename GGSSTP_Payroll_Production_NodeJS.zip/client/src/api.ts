const BASE_URL = '/api';

export function getToken(): string | null {
  return localStorage.getItem('ggsstp_auth_token');
}

export function setToken(token: string) {
  localStorage.setItem('ggsstp_auth_token', token);
}

export function clearToken() {
  localStorage.removeItem('ggsstp_auth_token');
}

export async function apiRequest<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers
  });

  if (response.status === 401) {
    clearToken();
    window.dispatchEvent(new Event('auth:unauthorized'));
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Request failed with status ${response.status}`);
  }

  return response.json();
}

export function downloadFile(url: string, filename: string) {
  const token = getToken();
  const fullUrl = `${BASE_URL}${url}${url.includes('?') ? '&' : '?'}token=${token || ''}`;
  
  const link = document.createElement('a');
  link.href = fullUrl;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
