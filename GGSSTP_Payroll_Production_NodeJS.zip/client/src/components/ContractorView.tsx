import React, { useState } from 'react';
import { Contractor, Circle } from '../types';
import { apiRequest } from '../api';
import { Building2, Layers, Plus, Phone, User, X, Edit3, Trash2, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ContractorViewProps {
  contractors: Contractor[];
  circles: Circle[];
  onRefresh: () => void;
}

export const ContractorView: React.FC<ContractorViewProps> = ({ contractors, circles, onRefresh }) => {
  // Add Contractor Modal
  const [isContractorModal, setIsContractorModal] = useState(false);
  const [contractorName, setContractorName] = useState('');
  const [contractorCode, setContractorCode] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');

  // Edit Contractor Modal
  const [editContractor, setEditContractor] = useState<Contractor | null>(null);
  const [editName, setEditName] = useState('');
  const [editCode, setEditCode] = useState('');
  const [editContact, setEditContact] = useState('');
  const [editPhoneNum, setEditPhoneNum] = useState('');

  // Add Circle Modal
  const [isCircleModal, setIsCircleModal] = useState(false);
  const [circleName, setCircleName] = useState('');
  const [circleCode, setCircleCode] = useState('');

  // Edit Circle Modal
  const [editCircle, setEditCircle] = useState<Circle | null>(null);
  const [editCirName, setEditCirName] = useState('');
  const [editCirCode, setEditCirCode] = useState('');

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Add Contractor
  const handleAddContractor = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/org/contractors', {
        method: 'POST',
        body: JSON.stringify({
          name: contractorName,
          code: contractorCode,
          contact_person: contactPerson,
          phone
        })
      });
      setIsContractorModal(false);
      setContractorName('');
      setContractorCode('');
      setContactPerson('');
      setPhone('');
      showNotification('success', 'Contractor added successfully.');
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to add contractor: ${err.message}`);
    }
  };

  // Open Edit Contractor
  const handleStartEditContractor = (c: Contractor) => {
    setEditContractor(c);
    setEditName(c.name);
    setEditCode(c.code || '');
    setEditContact(c.contact_person || '');
    setEditPhoneNum(c.phone || '');
  };

  // Save Edit Contractor
  const handleSaveEditContractor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editContractor) return;
    try {
      await apiRequest(`/org/contractors/${editContractor.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editName,
          code: editCode,
          contact_person: editContact,
          phone: editPhoneNum
        })
      });
      setEditContractor(null);
      showNotification('success', 'Contractor updated successfully.');
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to update contractor: ${err.message}`);
    }
  };

  // Delete Contractor
  const handleDeleteContractor = async (c: Contractor) => {
    const count = Number(c.employee_count) || 0;
    let confirmMsg = `Are you sure you want to delete contractor "${c.name}"?`;
    let force = false;
    if (count > 0) {
      confirmMsg += `\n\n⚠️ Caution: ${count} active workers are currently assigned to this contractor. Deleting will unassign them from this contractor. Proceed?`;
      force = true;
    }
    if (!window.confirm(confirmMsg)) return;

    try {
      await apiRequest(`/org/contractors/${c.id}${force ? '?force=true' : ''}`, {
        method: 'DELETE'
      });
      showNotification('success', `Contractor "${c.name}" deleted successfully.`);
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to delete contractor: ${err.message}`);
    }
  };

  // Add Circle
  const handleAddCircle = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/org/circles', {
        method: 'POST',
        body: JSON.stringify({ name: circleName, code: circleCode })
      });
      setIsCircleModal(false);
      setCircleName('');
      setCircleCode('');
      showNotification('success', 'Circle created successfully.');
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to add circle: ${err.message}`);
    }
  };

  // Open Edit Circle
  const handleStartEditCircle = (cir: Circle) => {
    setEditCircle(cir);
    setEditCirName(cir.name);
    setEditCirCode((cir as any).code || '');
  };

  // Save Edit Circle
  const handleSaveEditCircle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editCircle) return;
    try {
      await apiRequest(`/org/circles/${editCircle.id}`, {
        method: 'PUT',
        body: JSON.stringify({ name: editCirName, code: editCirCode })
      });
      setEditCircle(null);
      showNotification('success', 'Circle updated successfully.');
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to update circle: ${err.message}`);
    }
  };

  // Delete Circle
  const handleDeleteCircle = async (cir: Circle) => {
    const count = Number(cir.employee_count) || 0;
    let confirmMsg = `Are you sure you want to delete plant circle "${cir.name}"?`;
    let force = false;
    if (count > 0) {
      confirmMsg += `\n\n⚠️ Caution: ${count} active workers are assigned to this circle. Deleting will unassign them. Proceed?`;
      force = true;
    }
    if (!window.confirm(confirmMsg)) return;

    try {
      await apiRequest(`/org/circles/${cir.id}${force ? '?force=true' : ''}`, {
        method: 'DELETE'
      });
      showNotification('success', `Circle "${cir.name}" deleted successfully.`);
      onRefresh();
    } catch (err: any) {
      showNotification('error', `Failed to delete circle: ${err.message}`);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Toast Notification */}
      {notification && (
        <div style={{
          padding: '12px 18px',
          borderRadius: '8px',
          fontSize: '13px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          background: notification.type === 'success' ? '#ecfdf5' : '#fef2f2',
          border: `1px solid ${notification.type === 'success' ? '#a7f3d0' : '#fecaca'}`,
          color: notification.type === 'success' ? '#065f46' : '#991b1b'
        }}>
          {notification.type === 'success' ? <CheckCircle2 size={18} color="#059669" /> : <AlertTriangle size={18} color="#dc2626" />}
          <span style={{ fontWeight: 600 }}>{notification.message}</span>
        </div>
      )}

      {/* Contractors Section */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <div>
            <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Service Providers / Contractors</h2>
            <p style={{ fontSize: '12.5px', color: '#64748b' }}>Authorized contractual agencies operating across GGSSTP units</p>
          </div>
          <button onClick={() => setIsContractorModal(true)} className="btn btn-primary btn-sm">
            <Plus size={15} />
            <span>Add Contractor</span>
          </button>
        </div>

        <div className="grid-3">
          {contractors.map(c => (
            <div key={c.id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ background: '#eff6ff', padding: '6px', borderRadius: '6px', color: '#1e3a8a' }}>
                      <Building2 size={18} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '14.5px', color: '#0f172a' }}>{c.name}</div>
                      {c.code && <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>Code: {c.code}</div>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '4px' }}>
                    <button
                      onClick={() => handleStartEditContractor(c)}
                      className="btn btn-secondary btn-sm"
                      style={{ padding: '4px 6px' }}
                      title="Edit Contractor"
                    >
                      <Edit3 size={13} />
                    </button>
                    <button
                      onClick={() => handleDeleteContractor(c)}
                      className="btn btn-danger btn-sm"
                      style={{ padding: '4px 6px' }}
                      title="Delete Contractor"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <div style={{ fontSize: '12px', color: '#64748b', display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '10px' }}>
                  {c.contact_person && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <User size={12} />
                      <span>Contact: {c.contact_person}</span>
                    </div>
                  )}
                  {c.phone && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <Phone size={12} />
                      <span>Phone: {c.phone}</span>
                    </div>
                  )}
                </div>
              </div>

              <div style={{ marginTop: '14px', paddingTop: '10px', borderTop: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '11.5px', color: '#64748b' }}>Assigned Workforce:</span>
                <span className="badge" style={{ background: '#f8fafc', color: '#1e3a8a', border: '1px solid #cbd5e1', fontWeight: 700 }}>
                  {c.employee_count || 0} active workers
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Circles & Units Section */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <div>
            <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Plant Circles & Operational Divisions</h2>
            <p style={{ fontSize: '12.5px', color: '#64748b' }}>Thermal power plant operational divisions (EMC Circle, MM-1, Operation Circle, etc.)</p>
          </div>
          <button onClick={() => setIsCircleModal(true)} className="btn btn-secondary btn-sm">
            <Plus size={15} />
            <span>Add Circle</span>
          </button>
        </div>

        <div className="grid-3">
          {circles.map(cir => (
            <div key={cir.id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ background: '#ecfdf5', padding: '6px', borderRadius: '6px', color: '#059669' }}>
                      <Layers size={18} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '14.5px', color: '#0f172a' }}>{cir.name}</div>
                      {(cir as any).code && <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>Code: {(cir as any).code}</div>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '4px' }}>
                    <button
                      onClick={() => handleStartEditCircle(cir)}
                      className="btn btn-secondary btn-sm"
                      style={{ padding: '4px 6px' }}
                      title="Edit Circle"
                    >
                      <Edit3 size={13} />
                    </button>
                    <button
                      onClick={() => handleDeleteCircle(cir)}
                      className="btn btn-danger btn-sm"
                      style={{ padding: '4px 6px' }}
                      title="Delete Circle"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>

              <div style={{ marginTop: '14px', paddingTop: '10px', borderTop: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '11.5px', color: '#64748b' }}>Deployed Personnel:</span>
                <span className="badge" style={{ background: '#ecfdf5', color: '#065f46', border: '1px solid #a7f3d0', fontWeight: 700 }}>
                  {cir.employee_count || 0} contractual workers
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Contractor Modal */}
      {isContractorModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Add Service Provider / Contractor</h3>
              <button onClick={() => setIsContractorModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddContractor}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Contractor Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    placeholder="e.g. M/S Sodhi Erectors Ropar"
                    value={contractorName}
                    onChange={(e) => setContractorName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Contractor Code / ID</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. SE-01"
                    value={contractorCode}
                    onChange={(e) => setContractorCode(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Contact Person</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Name of contractor manager"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Phone / Mobile</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="+91..."
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setIsContractorModal(false)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Save Contractor</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Contractor Modal */}
      {editContractor && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Edit Service Provider: {editContractor.name}</h3>
              <button onClick={() => setEditContractor(null)}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveEditContractor}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Contractor Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Contractor Code / ID</label>
                  <input
                    type="text"
                    className="form-input"
                    value={editCode}
                    onChange={(e) => setEditCode(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Contact Person</label>
                  <input
                    type="text"
                    className="form-input"
                    value={editContact}
                    onChange={(e) => setEditContact(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Phone / Mobile</label>
                  <input
                    type="text"
                    className="form-input"
                    value={editPhoneNum}
                    onChange={(e) => setEditPhoneNum(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setEditContractor(null)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Circle Modal */}
      {isCircleModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '440px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Add Plant Circle</h3>
              <button onClick={() => setIsCircleModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleAddCircle}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Circle Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    placeholder="e.g. Operation Circle"
                    value={circleName}
                    onChange={(e) => setCircleName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Circle Code</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. OC-1"
                    value={circleCode}
                    onChange={(e) => setCircleCode(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setIsCircleModal(false)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Save Circle</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Circle Modal */}
      {editCircle && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '440px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Edit Plant Circle</h3>
              <button onClick={() => setEditCircle(null)}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveEditCircle}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Circle Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={editCirName}
                    onChange={(e) => setEditCirName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Circle Code</label>
                  <input
                    type="text"
                    className="form-input"
                    value={editCirCode}
                    onChange={(e) => setEditCirCode(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setEditCircle(null)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContractorView;
