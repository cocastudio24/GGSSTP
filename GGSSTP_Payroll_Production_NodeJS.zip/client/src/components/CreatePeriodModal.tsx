import React, { useState, useEffect } from 'react';
import { apiRequest } from '../api';
import { Calendar, Plus, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { PayrollPeriod } from '../types';

interface CreatePeriodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPeriodCreated: (newPeriodId: number) => void;
}

export const CreatePeriodModal: React.FC<CreatePeriodModalProps> = ({
  isOpen,
  onClose,
  onPeriodCreated
}) => {
  const [selectedMonth, setSelectedMonth] = useState<number>(10); // default to October
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [totalDays, setTotalDays] = useState<number>(31);
  const [notes, setNotes] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const months = [
    { value: 1, name: 'January', days: 31 },
    { value: 2, name: 'February', days: 28 },
    { value: 3, name: 'March', days: 31 },
    { value: 4, name: 'April', days: 30 },
    { value: 5, name: 'May', days: 31 },
    { value: 6, name: 'June', days: 30 },
    { value: 7, name: 'July', days: 31 },
    { value: 8, name: 'August', days: 31 },
    { value: 9, name: 'September', days: 30 },
    { value: 10, name: 'October', days: 31 },
    { value: 11, name: 'November', days: 30 },
    { value: 12, name: 'December', days: 31 }
  ];

  // Auto-adjust default days when month or year changes
  useEffect(() => {
    const isLeapYear = (selectedYear % 4 === 0 && selectedYear % 100 !== 0) || (selectedYear % 400 === 0);
    if (selectedMonth === 2) {
      setTotalDays(isLeapYear ? 29 : 28);
    } else {
      const found = months.find(m => m.value === selectedMonth);
      setTotalDays(found ? found.days : 30);
    }
  }, [selectedMonth, selectedYear]);

  if (!isOpen) return null;

  const handleCreatePeriod = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      setLoading(true);
      const res = await apiRequest<{ period: PayrollPeriod }>('/payroll/periods', {
        method: 'POST',
        body: JSON.stringify({
          month: selectedMonth,
          year: selectedYear,
          totalDays,
          notes
        })
      });

      onPeriodCreated(res.period.id);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create payroll period');
    } finally {
      setLoading(false);
    }
  };

  const selectedMonthObj = months.find(m => m.value === selectedMonth);

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '480px' }}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Calendar size={18} color="#1e3a8a" />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#0f172a', margin: 0 }}>
              Create New Payroll Month
            </h3>
          </div>
          <button onClick={onClose} style={{ color: '#64748b' }}><X size={20} /></button>
        </div>

        <form onSubmit={handleCreatePeriod}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <p style={{ fontSize: '12.5px', color: '#64748b', margin: 0 }}>
              Choose the target month and year for processing salaries. All active contractual employees will be initialized into this cycle automatically.
            </p>

            {error && (
              <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', padding: '10px 14px', borderRadius: '6px', fontSize: '12.5px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <AlertCircle size={16} />
                <span>{error}</span>
              </div>
            )}

            <div className="grid-2">
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Payroll Month *</label>
                <select
                  className="form-input"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(Number(e.target.value))}
                >
                  {months.map(m => (
                    <option key={m.value} value={m.value}>
                      {m.name} ({m.value.toString().padStart(2, '0')})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Payroll Year *</label>
                <select
                  className="form-input"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(Number(e.target.value))}
                >
                  {[2024, 2025, 2026, 2027, 2028, 2029, 2030].map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Total Calendar / Payroll Days *</label>
              <input
                type="number"
                min="1"
                max="31"
                required
                className="form-input"
                value={totalDays}
                onChange={(e) => setTotalDays(Number(e.target.value))}
              />
              <span style={{ fontSize: '11px', color: '#64748b' }}>
                Default for {selectedMonthObj?.name} is {selectedMonthObj?.days} days. Proportions are calculated using this base.
              </span>
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Cycle Description / Notes (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Regular Monthly Salary Disbursement"
                className="form-input"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '12px', color: '#475569' }}>
              ✓ All active contractual personnel will be carried forward.<br />
              ✓ Initial salaries computed using standard GGSSTP formulas.<br />
              ✓ You can upload an Excel salary sheet or adjust attendance after creation.
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" onClick={onClose} className="btn btn-secondary">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              <Plus size={15} />
              <span>{loading ? 'Creating Cycle...' : `Create ${selectedMonthObj?.name} ${selectedYear} Payroll`}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreatePeriodModal;
