import React, { useState, useEffect } from 'react';
import { Employee, Designation, Contractor, Circle } from '../types';
import { apiRequest, getToken } from '../api';
import {
  Search, Plus, Filter, Eye, EyeOff, Edit2, UserCheck,
  UserX, Download, CheckSquare, Square, X, AlertCircle,
  FileSpreadsheet
} from 'lucide-react';

interface EmployeeViewProps {
  designations: Designation[];
  contractors: Contractor[];
  circles: Circle[];
}

export const EmployeeView: React.FC<EmployeeViewProps> = ({ designations, contractors, circles }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDesignation, setSelectedDesignation] = useState('');
  const [selectedContractor, setSelectedContractor] = useState('');
  const [maskSensitive, setMaskSensitive] = useState(true);
  const [exporting, setExporting] = useState(false);

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Selection for bulk actions
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Add/Edit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Partial<Employee> | null>(null);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      let query = `/employees?page=${page}&limit=25`;
      if (search) query += `&search=${encodeURIComponent(search)}`;
      if (selectedDesignation) query += `&designationId=${selectedDesignation}`;
      if (selectedContractor) query += `&contractorId=${selectedContractor}`;

      const res = await apiRequest<{ employees: Employee[]; pagination: any }>(query);
      setEmployees(res.employees);
      setTotalPages(res.pagination.totalPages);
      setTotalCount(res.pagination.total);
    } catch (err: any) {
      alert(`Error loading employees: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, [page, search, selectedDesignation, selectedContractor]);

  const handleSelectAll = () => {
    if (selectedIds.length === employees.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(employees.map(e => e.id));
    }
  };

  const handleToggleSelect = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const maskString = (val?: string) => {
    if (!val) return '—';
    if (!maskSensitive) return val;
    if (val.length <= 4) return '****';
    return val.slice(0, 2) + '******' + val.slice(-4);
  };

  const handleOpenAdd = () => {
    setEditingEmployee({
      emp_code: `EMP-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      father_name: '',
      uan: '',
      designation_id: designations[0]?.id,
      dob: '',
      date_of_joining: '',
      qualification: '',
      experience_years: '',
      bank_account: '',
      ifsc: '',
      esi_number: '',
      is_active: true
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setEditingEmployee({ ...emp });
    setIsModalOpen(true);
  };

  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;

    try {
      if (editingEmployee.id) {
        await apiRequest(`/employees/${editingEmployee.id}`, {
          method: 'PUT',
          body: JSON.stringify(editingEmployee)
        });
      } else {
        await apiRequest(`/employees`, {
          method: 'POST',
          body: JSON.stringify(editingEmployee)
        });
      }
      setIsModalOpen(false);
      setEditingEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      alert(`Failed to save employee: ${err.message}`);
    }
  };

  const handleToggleActive = async (id: number, currentStatus: boolean) => {
    try {
      await apiRequest(`/employees/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ is_active: !currentStatus })
      });
      fetchEmployees();
    } catch (err: any) {
      alert(`Failed to update status: ${err.message}`);
    }
  };

  const handleBulkDeactivate = async () => {
    if (!window.confirm(`Deactivate ${selectedIds.length} selected employees?`)) return;
    try {
      await apiRequest('/employees/bulk-update', {
        method: 'POST',
        body: JSON.stringify({ ids: selectedIds, is_active: false })
      });
      setSelectedIds([]);
      fetchEmployees();
    } catch (err: any) {
      alert(`Bulk update failed: ${err.message}`);
    }
  };

  const handleExportEmployees = async (onlySelected: boolean = true) => {
    try {
      setExporting(true);
      const token = getToken();
      const body: any = {};
      if (onlySelected && selectedIds.length > 0) {
        body.ids = selectedIds;
      } else {
        if (search) body.search = search;
        if (selectedDesignation) body.designationId = Number(selectedDesignation);
        if (selectedContractor) body.contractorId = Number(selectedContractor);
      }

      const response = await fetch('/api/export/employees-xlsx', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error('Failed to generate employee master export');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const countLabel = (onlySelected && selectedIds.length > 0) ? `Selected_${selectedIds.length}` : 'Filtered';
      a.download = `GGSSTP_Employees_Master_${countLabel}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err: any) {
      alert(`Export failed: ${err.message}`);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Top Action Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Employee Master Register</h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>
            {totalCount} total contractual employees registered across all plant service providers
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={() => handleExportEmployees(selectedIds.length > 0)}
            disabled={exporting}
            className="btn btn-secondary btn-sm"
            style={{ borderColor: '#059669', color: '#065f46', background: '#ecfdf5', fontWeight: 600 }}
            title={selectedIds.length > 0 ? `Export ${selectedIds.length} selected employees to Excel` : 'Export all filtered employees to Excel'}
          >
            <Download size={15} color="#059669" />
            <span>
              {exporting
                ? 'Exporting...'
                : selectedIds.length > 0
                  ? `Export Selected (${selectedIds.length})`
                  : 'Export Employees (Excel)'}
            </span>
          </button>
          <button
            onClick={() => setMaskSensitive(!maskSensitive)}
            className="btn btn-secondary btn-sm"
            title="Toggle Bank/UAN masking"
          >
            {maskSensitive ? <EyeOff size={15} /> : <Eye size={15} />}
            <span>{maskSensitive ? 'Unmask Confidential Numbers' : 'Mask Confidential Numbers'}</span>
          </button>
          <button onClick={handleOpenAdd} className="btn btn-primary btn-sm">
            <Plus size={16} />
            <span>Add New Employee</span>
          </button>
        </div>
      </div>

      {/* Filters Card */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '240px' }}>
            <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '10px' }} />
            <input
              type="text"
              placeholder="Search by name, code, UAN, or bank account..."
              className="form-input"
              style={{ paddingLeft: '36px' }}
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>

          <div style={{ width: '200px' }}>
            <select
              value={selectedDesignation}
              onChange={(e) => { setSelectedDesignation(e.target.value); setPage(1); }}
              className="form-input"
            >
              <option value="">All Designations</option>
              {designations.map(d => (
                <option key={d.id} value={d.id}>{d.name} ({d.alias})</option>
              ))}
            </select>
          </div>

          <div style={{ width: '220px' }}>
            <select
              value={selectedContractor}
              onChange={(e) => { setSelectedContractor(e.target.value); setPage(1); }}
              className="form-input"
            >
              <option value="">All Contractors</option>
              {contractors.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {selectedIds.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginLeft: 'auto' }}>
              <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e3a8a' }}>
                {selectedIds.length} Selected:
              </span>
              <button
                onClick={() => handleExportEmployees(true)}
                disabled={exporting}
                className="btn btn-sm"
                style={{ borderColor: '#059669', color: '#065f46', background: '#ecfdf5', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '6px' }}
                title={`Export ${selectedIds.length} selected employees to Excel`}
              >
                <Download size={14} color="#059669" />
                <span>{exporting ? 'Exporting...' : `Export Selected (${selectedIds.length})`}</span>
              </button>
              <button onClick={handleBulkDeactivate} className="btn btn-danger btn-sm">
                Deactivate Selected
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Employees Table */}
      <div className="table-container">
        <table className="custom-table">
          <thead>
            <tr>
              <th style={{ width: '40px' }}>
                <input
                  type="checkbox"
                  checked={selectedIds.length > 0 && selectedIds.length === employees.length}
                  onChange={handleSelectAll}
                />
              </th>
              <th>Emp Code</th>
              <th>Name & Father's Name</th>
              <th>Designation</th>
              <th>Contractor / Circle</th>
              <th>UAN</th>
              <th>Bank A/c & IFSC</th>
              <th>ESI No</th>
              <th>Joining Date</th>
              <th>Status</th>
              <th style={{ textAlign: 'center' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={11} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                  Loading employee records...
                </td>
              </tr>
            ) : employees.length === 0 ? (
              <tr>
                <td colSpan={11} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                  No matching employees found.
                </td>
              </tr>
            ) : (
              employees.map(emp => {
                const isSelected = selectedIds.includes(emp.id);
                return (
                  <tr key={emp.id} style={{ background: isSelected ? '#eff6ff' : undefined }}>
                    <td>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelect(emp.id)}
                      />
                    </td>
                    <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>
                      {emp.emp_code}
                    </td>
                    <td>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>{emp.name}</div>
                      <div style={{ fontSize: '11.5px', color: '#64748b' }}>S/o {emp.father_name || '—'}</div>
                    </td>
                    <td>
                      <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b', border: '1px solid #cbd5e1' }}>
                        {emp.designation_alias || 'SW'}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '12px', fontWeight: 500, color: '#1e293b' }}>
                        {emp.contractor_name || 'Direct / Undefined'}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>
                        {emp.circle_name || 'GGSSTP'} • {emp.department_name || ''}
                      </div>
                    </td>
                    <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>
                      {maskString(emp.uan)}
                    </td>
                    <td>
                      <div style={{ fontFamily: 'monospace', fontSize: '12px', fontWeight: 600 }}>
                        {maskString(emp.bank_account)}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>
                        {emp.ifsc || '—'}
                      </div>
                    </td>
                    <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>
                      {maskString(emp.esi_number)}
                    </td>
                    <td style={{ fontSize: '12px' }}>
                      {emp.date_of_joining || '—'}
                    </td>
                    <td>
                      {emp.is_active ? (
                        <span className="badge badge-active">Active</span>
                      ) : (
                        <span className="badge badge-inactive">Inactive</span>
                      )}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'inline-flex', gap: '6px' }}>
                        <button
                          onClick={() => handleOpenEdit(emp)}
                          className="btn btn-secondary btn-sm"
                          title="Edit Employee"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => handleToggleActive(emp.id, emp.is_active)}
                          className={`btn ${emp.is_active ? 'btn-danger' : 'btn-success'} btn-sm`}
                          title={emp.is_active ? 'Deactivate' : 'Reactivate'}
                        >
                          {emp.is_active ? <UserX size={13} /> : <UserCheck size={13} />}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
          <div style={{ fontSize: '13px', color: '#64748b' }}>
            Showing page {page} of {totalPages}
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="btn btn-secondary btn-sm"
            >
              Previous
            </button>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="btn btn-secondary btn-sm"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && editingEmployee && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '750px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>
                {editingEmployee.id ? `Edit Employee (${editingEmployee.emp_code})` : 'Register New Contractual Employee'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <form onSubmit={handleSaveEmployee}>
              <div className="modal-body">
                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Employee Code *</label>
                    <input
                      type="text"
                      required
                      className="form-input"
                      value={editingEmployee.emp_code || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, emp_code: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Full Name *</label>
                    <input
                      type="text"
                      required
                      className="form-input"
                      value={editingEmployee.name || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, name: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Father's Name</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.father_name || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, father_name: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Designation</label>
                    <select
                      className="form-input"
                      value={editingEmployee.designation_id || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, designation_id: Number(e.target.value) })}
                    >
                      {designations.map(d => (
                        <option key={d.id} value={d.id}>{d.name} ({d.alias})</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Contractor / Service Provider</label>
                    <select
                      className="form-input"
                      value={editingEmployee.contractor_id || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, contractor_id: Number(e.target.value) || undefined })}
                    >
                      <option value="">Select Contractor</option>
                      {contractors.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Plant Circle</label>
                    <select
                      className="form-input"
                      value={editingEmployee.circle_id || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, circle_id: Number(e.target.value) || undefined })}
                    >
                      <option value="">Select Circle</option>
                      {circles.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">Bank Account Number</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.bank_account || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, bank_account: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">IFSC Code</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.ifsc || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, ifsc: e.target.value.toUpperCase() })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">UAN Number</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.uan || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, uan: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid-3">
                  <div className="form-group">
                    <label className="form-label">ESI Identifier</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.esi_number || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, esi_number: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Date of Joining</label>
                    <input
                      type="text"
                      placeholder="DD.MM.YYYY"
                      className="form-input"
                      value={editingEmployee.date_of_joining || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, date_of_joining: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Date of Birth</label>
                    <input
                      type="text"
                      placeholder="DD-MM-YYYY"
                      className="form-input"
                      value={editingEmployee.dob || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, dob: e.target.value })}
                    />
                  </div>
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Qualification</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.qualification || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, qualification: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Experience (Years)</label>
                    <input
                      type="text"
                      className="form-input"
                      value={editingEmployee.experience_years || ''}
                      onChange={(e) => setEditingEmployee({ ...editingEmployee, experience_years: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" onClick={() => setIsModalOpen(false)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Save Employee Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
