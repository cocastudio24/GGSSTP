import React, { useState } from 'react';
import { apiRequest } from '../api';
import { FileSpreadsheet, Upload, CheckCircle2, AlertTriangle, Layers, Play } from 'lucide-react';

interface ImportViewProps {
  onRefreshAll: () => void;
}

export const ImportView: React.FC<ImportViewProps> = ({ onRefreshAll }) => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [parsedResult, setParsedResult] = useState<any>(null);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [committing, setCommitting] = useState(false);
  const [commitMessage, setCommitMessage] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setParsedResult(null);
      setCommitMessage(null);
    }
  };

  const handleUploadAndInspect = async () => {
    if (!file) return;
    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('file', file);

      const res = await apiRequest('/import/upload', {
        method: 'POST',
        body: formData
      });

      setParsedResult(res);
      if (res.sheets && res.sheets.length > 0) {
        setSelectedSheet(res.sheets[0].sheetName);
      }
    } catch (err: any) {
      alert(`Failed to inspect workbook: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleCommit = async () => {
    if (!parsedResult || !selectedSheet) return;
    const rows = parsedResult.parsedData[selectedSheet];
    if (!rows || rows.length === 0) {
      alert('Selected sheet contains no valid employee rows');
      return;
    }

    try {
      setCommitting(true);
      const res = await apiRequest('/import/commit', {
        method: 'POST',
        body: JSON.stringify({
          rows,
          month: 9,
          year: 2026
        })
      });

      setCommitMessage(`Successfully committed ${res.result.totalRecords} records for September 2026! Created: ${res.result.createdCount}, Updated: ${res.result.updatedCount}`);
      onRefreshAll();
    } catch (err: any) {
      alert(`Commit failed: ${err.message}`);
    } finally {
      setCommitting(false);
    }
  };

  const handleSeedReferenceWorkbook = async () => {
    if (!window.confirm('Seed reference data from MM-1 and EMC sheets into September 2026?')) return;
    try {
      setCommitting(true);
      const res = await apiRequest('/import/seed-reference', {
        method: 'POST'
      });
      setCommitMessage(res.message);
      onRefreshAll();
    } catch (err: any) {
      alert(`Seed failed: ${err.message}`);
    } finally {
      setCommitting(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Excel Import Center</h2>
        <p style={{ fontSize: '12.5px', color: '#64748b' }}>
          Upload contractual payroll registers (supports MM-1, EMC, and Operation Circle multi-sheet formats)
        </p>
      </div>

      {/* One-Click Reference Seeder Card */}
      <div className="card" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #172554 100%)', color: '#ffffff', borderColor: '#1e3a8a' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '16px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FileSpreadsheet size={20} color="#f59e0b" />
              <span>Reference Workbook Auto-Loader (SALARY SHEET-for EPF Sepf 2026.xlsx)</span>
            </div>
            <p style={{ fontSize: '12.5px', color: '#bfdbfe', marginTop: '4px' }}>
              Instantly load and reconcile the 66 reference employees across MM-1 and EMC worksheets into September 2026.
            </p>
          </div>
          <button
            onClick={handleSeedReferenceWorkbook}
            disabled={committing}
            className="btn btn-primary"
            style={{ background: '#f59e0b', color: '#0f172a', fontWeight: 700, borderColor: '#f59e0b' }}
          >
            <Play size={16} fill="#0f172a" />
            <span>Load Reference Sheets</span>
          </button>
        </div>
      </div>

      {commitMessage && (
        <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '10px', padding: '16px', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <CheckCircle2 size={20} color="#059669" />
          <span style={{ fontWeight: 600, color: '#065f46', fontSize: '13.5px' }}>{commitMessage}</span>
        </div>
      )}

      {/* File Upload Box */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <Upload size={18} color="#1e3a8a" />
            <span>Upload New Spreadsheet (.xlsx, .xls)</span>
          </div>
        </div>

        <div style={{ border: '2px dashed #cbd5e1', borderRadius: '10px', padding: '30px', textAlign: 'center', background: '#f8fafc' }}>
          <input
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileChange}
            id="excel-file-input"
            style={{ display: 'none' }}
          />
          <label htmlFor="excel-file-input" style={{ cursor: 'pointer', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <FileSpreadsheet size={36} color="#1e3a8a" />
            <span style={{ fontWeight: 600, color: '#1e3a8a', fontSize: '14px' }}>
              {file ? file.name : 'Click to select or drop Excel workbook'}
            </span>
            <span style={{ fontSize: '12px', color: '#64748b' }}>
              Supports XLSX files with MM-1, EMC, and Operation Circle worksheets
            </span>
          </label>
        </div>

        {file && (
          <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <button
              onClick={handleUploadAndInspect}
              disabled={uploading}
              className="btn btn-primary"
            >
              {uploading ? 'Analyzing Workbook...' : 'Inspect Sheets & Headers'}
            </button>
          </div>
        )}
      </div>

      {/* Parsed Inspection & Preview */}
      {parsedResult && (
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <Layers size={18} color="#1e3a8a" />
              <span>Inspection Preview: {parsedResult.fileName}</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <span style={{ fontSize: '13px', fontWeight: 600 }}>Select Sheet to Commit:</span>
              <select
                value={selectedSheet}
                onChange={(e) => setSelectedSheet(e.target.value)}
                className="form-input"
                style={{ width: 'auto' }}
              >
                {parsedResult.sheets.map((s: any) => (
                  <option key={s.sheetName} value={s.sheetName}>
                    {s.sheetName} ({s.totalRows} employees found)
                  </option>
                ))}
              </select>
              <button
                onClick={handleCommit}
                disabled={committing}
                className="btn btn-success btn-sm"
              >
                {committing ? 'Saving to Database...' : 'Commit Selected Sheet to Payroll'}
              </button>
            </div>
          </div>

          {/* Sample rows preview table */}
          {selectedSheet && parsedResult.parsedData[selectedSheet] && (
            <div className="table-container" style={{ marginTop: '14px' }}>
              <table className="custom-table">
                <thead>
                  <tr>
                    <th>Emp Code</th>
                    <th>Name</th>
                    <th>Father's Name</th>
                    <th>Designation</th>
                    <th>Contractor</th>
                    <th>UAN</th>
                    <th>Bank Account</th>
                    <th>Days</th>
                    <th>Present</th>
                    <th>Monthly Perf</th>
                    <th>Bonus</th>
                  </tr>
                </thead>
                <tbody>
                  {parsedResult.parsedData[selectedSheet].slice(0, 10).map((row: any, i: number) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>{row.empCode}</td>
                      <td style={{ fontWeight: 600 }}>{row.name}</td>
                      <td>{row.fatherName || '—'}</td>
                      <td><span className="badge" style={{ background: '#f1f5f9' }}>{row.designationAlias}</span></td>
                      <td style={{ fontSize: '12px' }}>{row.contractorName || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{row.uan || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>{row.bankAccount || '—'}</td>
                      <td>{row.totalDays}</td>
                      <td style={{ fontWeight: 600 }}>{row.presentDays}</td>
                      <td>₹{row.perfAllowanceMonthly}</td>
                      <td>₹{row.bonus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div style={{ padding: '10px 14px', fontSize: '12px', color: '#64748b', background: '#f8fafc', borderTop: '1px solid #e2e8f0' }}>
                Showing first 10 of {parsedResult.parsedData[selectedSheet].length} parsed records from {selectedSheet}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
