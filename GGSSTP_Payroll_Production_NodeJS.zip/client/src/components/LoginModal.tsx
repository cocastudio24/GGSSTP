import React, { useState } from 'react';
import { apiRequest, setToken } from '../api';
import { User } from '../types';
import { Zap, Shield, KeyRound, User as UserIcon } from 'lucide-react';

interface LoginModalProps {
  onSuccess: (user: User) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onSuccess }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin@ggsstp2026');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await apiRequest<{ token: string; user: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password })
      });
      setToken(res.token);
      onSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectDemoUser = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
  };

  return (
    <div className="modal-overlay" style={{ background: 'rgba(15, 23, 42, 0.85)' }}>
      <div className="modal-content" style={{ maxWidth: '440px', padding: '10px' }}>
        <div style={{ textAlign: 'center', padding: '24px 20px 10px 20px' }}>
          <div style={{ display: 'inline-flex', padding: '12px', background: '#1e3a8a', borderRadius: '50%', marginBottom: '12px' }}>
            <Zap size={28} color="#f59e0b" fill="#f59e0b" />
          </div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>GGSSTP PAYROLL PORTAL</h2>
          <p style={{ fontSize: '12px', color: '#64748b', marginTop: '4px' }}>
            Guru Gobind Singh Super Thermal Plant, Rupnagar
          </p>
        </div>

        {error && (
          <div style={{ margin: '0 20px', background: '#fef2f2', border: '1px solid #fecaca', color: '#b91c1c', padding: '10px 14px', borderRadius: '6px', fontSize: '12.5px' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} style={{ padding: '10px 20px 20px 20px' }}>
          <div className="form-group">
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <UserIcon size={14} />
              <span>Username</span>
            </label>
            <input
              type="text"
              required
              className="form-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <KeyRound size={14} />
              <span>Password</span>
            </label>
            <input
              type="password"
              required
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{ width: '100%', padding: '10px', marginTop: '6px' }}
          >
            {loading ? 'Authenticating...' : 'Sign In to Portal'}
          </button>

          {/* Quick Login Shortcuts */}
          <div style={{ marginTop: '20px', borderTop: '1px solid #e2e8f0', paddingTop: '16px' }}>
            <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase', marginBottom: '8px' }}>
              Quick Login Roles:
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '6px' }}>
              <button
                type="button"
                onClick={() => handleSelectDemoUser('admin', 'admin@ggsstp2026')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '11px', justifyContent: 'flex-start' }}
              >
                Super Admin
              </button>
              <button
                type="button"
                onClick={() => handleSelectDemoUser('payroll_admin', 'payroll@ggsstp2026')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '11px', justifyContent: 'flex-start' }}
              >
                Payroll Admin
              </button>
              <button
                type="button"
                onClick={() => handleSelectDemoUser('operator', 'operator@ggsstp2026')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '11px', justifyContent: 'flex-start' }}
              >
                Operator
              </button>
              <button
                type="button"
                onClick={() => handleSelectDemoUser('auditor', 'auditor@ggsstp2026')}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '11px', justifyContent: 'flex-start' }}
              >
                Auditor
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
