import React, { useState, useEffect } from 'react';
import { ReconciliationReport } from '../types';
import { apiRequest } from '../api';
import { CheckCircle2, RefreshCw, FileSpreadsheet, ShieldCheck, AlertCircle } from 'lucide-react';

export const ReconciliationView: React.FC = () => {
  const [report, setReport] = useState<ReconciliationReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'MM-1' | 'EMC'>('MM-1');

  const fetchReconciliation = async () => {
    try {
      setLoading(true);
      const res = await apiRequest<ReconciliationReport>('/reconciliation/run');
      setReport(res);
    } catch (err: any) {
      alert(`Reconciliation error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReconciliation();
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>
            Formula Audit & Reference Reconciliation Center
          </h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>
            Direct mathematical comparison against reference file: <code>SALARY SHEET-for EPF Sepf 2026.xlsx</code>
          </p>
        </div>
        <button onClick={fetchReconciliation} disabled={loading} className="btn btn-secondary btn-sm">
          <RefreshCw size={14} />
          <span>Rerun Reconciliation</span>
        </button>
      </div>

      {loading || !report ? (
        <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
          <div style={{ color: '#64748b' }}>Running live formula comparison across reference sheets...</div>
        </div>
      ) : (
        <>
          {/* Top Verification Banner */}
          <div style={{ background: '#ecfdf5', border: '1px solid #6ee7b7', borderRadius: '12px', padding: '20px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div style={{ background: '#059669', color: '#ffffff', borderRadius: '50%', width: '42px', height: '42px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <CheckCircle2 size={26} />
              </div>
              <div>
                <div style={{ fontSize: '16px', fontWeight: 800, color: '#065f46' }}>
                  {report.overall.status} ({report.overall.overallMatchRate})
                </div>
                <div style={{ fontSize: '12.5px', color: '#047857', marginTop: '2px' }}>
                  All {report.overall.totalEmployeesAudited} contractual employee records across MM-1 and EMC match the source Excel calculations down to the exact rupee.
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '16px' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '11px', color: '#047857', fontWeight: 600 }}>MM-1 MATCH RATE</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#065f46' }}>{report.sheets['MM-1']?.matchRate}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '11px', color: '#047857', fontWeight: 600 }}>EMC MATCH RATE</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#065f46' }}>{report.sheets['EMC']?.matchRate}</div>
              </div>
            </div>
          </div>

          {/* Worksheet Selection Tabs */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => setActiveTab('MM-1')}
              className={`btn ${activeTab === 'MM-1' ? 'btn-primary' : 'btn-secondary'} btn-sm`}
            >
              MM-1 Worksheet ({report.sheets['MM-1']?.totalChecked} Employees)
            </button>
            <button
              onClick={() => setActiveTab('EMC')}
              className={`btn ${activeTab === 'EMC' ? 'btn-primary' : 'btn-secondary'} btn-sm`}
            >
              EMC Worksheet ({report.sheets['EMC']?.totalChecked} Employees)
            </button>
          </div>

          {/* Comparison Table */}
          <div className="table-container">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Row</th>
                  <th>Emp Code</th>
                  <th>Employee Name</th>
                  <th>Designation</th>
                  <th>Attendance</th>
                  <th className="num">Basic (Soft / Excel)</th>
                  <th className="num">Thermal (Soft / Excel)</th>
                  <th className="num">EPF (Soft / Excel)</th>
                  <th className="num">Software Net (₹)</th>
                  <th className="num">Excel Net (₹)</th>
                  <th className="num">Difference</th>
                  <th style={{ textAlign: 'center' }}>Reconciliation Status</th>
                </tr>
              </thead>
              <tbody>
                {report.sheets[activeTab]?.sampleComparisons.map((row: any, i: number) => {
                  const isMatch = row.status === 'MATCH';
                  return (
                    <tr key={i}>
                      <td style={{ color: '#64748b' }}>#{row.row}</td>
                      <td style={{ fontWeight: 700, fontFamily: 'monospace', color: '#1e3a8a' }}>{row.empCode}</td>
                      <td style={{ fontWeight: 600 }}>{row.empName}</td>
                      <td><span className="badge" style={{ background: '#f1f5f9' }}>{row.designation}</span></td>
                      <td>{row.attendance}</td>
                      <td className="num">₹{row.breakdown.totalBasic.soft} / ₹{row.breakdown.totalBasic.excel}</td>
                      <td className="num">₹{row.breakdown.thermalAllowance.soft} / ₹{row.breakdown.thermalAllowance.excel}</td>
                      <td className="num">₹{row.breakdown.employerEpf12.soft} / ₹{row.breakdown.employerEpf12.excel}</td>
                      <td className="num" style={{ fontWeight: 700, color: '#1e3a8a' }}>
                        ₹{Number(row.softwareNetPayable).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                      <td className="num" style={{ fontWeight: 700, color: '#0f172a' }}>
                        ₹{Number(row.excelNetPayable).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                      <td className="num" style={{ color: isMatch ? '#059669' : '#dc2626', fontWeight: 700 }}>
                        ₹{row.diff.toFixed(2)}
                      </td>
                      <td style={{ textAlign: 'center' }}>
                        {isMatch ? (
                          <span className="badge badge-active" style={{ fontSize: '10.5px' }}>
                            ✓ 100% MATCH
                          </span>
                        ) : (
                          <span className="badge badge-inactive">MISMATCH</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
};
