import React, { useState } from 'react';
import { apiRequest, downloadFile } from '../api';
import { Settings, Database, ShieldAlert, Download, Upload, CheckCircle2 } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [restoring, setRestoring] = useState(false);
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  const handleExportBackup = () => {
    downloadFile('/backup/export', `GGSSTP_Backup_${new Date().toISOString().split('T')[0]}.json`);
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = async (evt) => {
      try {
        setRestoring(true);
        const json = JSON.parse(evt.target?.result as string);
        const res = await apiRequest('/backup/restore', {
          method: 'POST',
          body: JSON.stringify({ data: json.data || json })
        });
        setRestoreStatus('Backup verified and logged in security ledger.');
      } catch (err: any) {
        alert(`Restore failed: ${err.message}`);
      } finally {
        setRestoring(false);
      }
    };

    reader.readAsText(file);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>System Settings & Statutory Compliance</h2>
        <p style={{ fontSize: '12.5px', color: '#64748b' }}>Configure plant parameters, labor welfare rules, and database snapshots</p>
      </div>

      {/* Statutory Notice */}
      <div className="card" style={{ borderLeft: '4px solid #d97706', background: '#fffbeb' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
          <ShieldAlert size={20} color="#d97706" />
          <span style={{ fontWeight: 700, fontSize: '14px', color: '#92400e' }}>
            Punjab Contractual Labor & Statutory Compliance Notice
          </span>
        </div>
        <p style={{ fontSize: '12.5px', color: '#b45309', lineHeight: 1.6 }}>
          The initial contribution ceilings (EPF ₹25,000 threshold, ESI ₹21,000 threshold, Punjab LWF ₹20 employer / ₹5 employee) are configured according to the September 2026 plant reference workbook. Prior to official statutory EPF/ESI e-challan submissions, ensure rate changes mandated by the Punjab Government or EPFO are verified by the designated Accounts Officer.
        </p>
      </div>

      {/* Backup & Disaster Recovery */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <Database size={18} color="#1e3a8a" />
            <span>Database Backup & Restoration</span>
          </div>
        </div>

        <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '18px' }}>
          Create instant portable JSON snapshots containing all employee records, salary rates, historical payroll periods, overrides, and audit logs.
        </p>

        <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
          <button onClick={handleExportBackup} className="btn btn-primary">
            <Download size={16} />
            <span>Export Complete System Backup (.json)</span>
          </button>

          <label className="btn btn-secondary" style={{ cursor: 'pointer' }}>
            <Upload size={16} />
            <span>Restore Backup JSON</span>
            <input
              type="file"
              accept=".json"
              onChange={handleRestoreFile}
              style={{ display: 'none' }}
            />
          </label>
        </div>

        {restoreStatus && (
          <div style={{ marginTop: '16px', background: '#ecfdf5', padding: '10px 14px', borderRadius: '6px', color: '#065f46', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <CheckCircle2 size={16} />
            <span>{restoreStatus}</span>
          </div>
        )}
      </div>

      {/* System Diagnostics */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <Settings size={18} color="#1e3a8a" />
            <span>Plant Deployment Diagnostics</span>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', fontSize: '13px' }}>
          <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px' }}>
            <div style={{ color: '#64748b', fontSize: '11.5px' }}>Application Name</div>
            <div style={{ fontWeight: 700, color: '#0f172a' }}>GGSSTP Payroll System</div>
          </div>
          <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px' }}>
            <div style={{ color: '#64748b', fontSize: '11.5px' }}>Power Plant Location</div>
            <div style={{ fontWeight: 700, color: '#0f172a' }}>Rupnagar (Ropar), Punjab</div>
          </div>
          <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px' }}>
            <div style={{ color: '#64748b', fontSize: '11.5px' }}>Persistence Engine</div>
            <div style={{ fontWeight: 700, color: '#059669' }}>PostgreSQL (PGlite Active)</div>
          </div>
        </div>
      </div>
    </div>
  );
};
