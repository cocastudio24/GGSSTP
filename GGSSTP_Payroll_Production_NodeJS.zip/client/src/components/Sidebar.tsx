import React from 'react';
import {
  LayoutDashboard, Users, Calculator, Award, Building2,
  FileSpreadsheet, Download, CheckCircle2, ShieldCheck,
  History, Settings, Zap, Sliders
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, setCurrentTab, userRole }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'employees', label: 'Employee Master', icon: Users },
    { id: 'payroll', label: 'Monthly Payroll', icon: Calculator },
    { id: 'formula-rules', label: 'Formula & Rules Engine', icon: Sliders },
    { id: 'designations', label: 'Designations & Rates', icon: Award },
    { id: 'contractors', label: 'Contractors & Circles', icon: Building2 },
    { id: 'import', label: 'Excel Import Center', icon: FileSpreadsheet },
    { id: 'export', label: 'Reports & Exports', icon: Download },
    { id: 'reconciliation', label: 'Formula Reconciliation', icon: CheckCircle2 },
    { id: 'users', label: 'User Management', icon: ShieldCheck, adminOnly: true },
    { id: 'audit', label: 'Audit Logs', icon: History },
    { id: 'settings', label: 'Settings & Backups', icon: Settings }
  ];

  const filteredItems = navItems.filter(item => {
    if (item.adminOnly && userRole !== 'Super Administrator') return false;
    return true;
  });

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-brand-title">
          <Zap size={20} color="#f59e0b" fill="#f59e0b" />
          <span>GGSSTP PAYROLL</span>
        </div>
        <div className="sidebar-brand-sub">Guru Gobind Singh ST Plant, Rupnagar</div>
      </div>

      <nav className="sidebar-nav">
        {filteredItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setCurrentTab(item.id)}
            >
              <Icon size={18} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div style={{ color: '#94a3b8', fontSize: '11px' }}>Contractual Labor Cell</div>
        <div style={{ color: '#64748b', fontSize: '10px', marginTop: '2px' }}>v2.0.0 (Sep 2026 Compatible)</div>
      </div>
    </aside>
  );
};
