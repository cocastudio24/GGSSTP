import React, { useState } from 'react';
import { User as UserType, PayrollPeriod } from '../types';
import { LogOut, Calendar, Shield, Activity, Plus } from 'lucide-react';
import { CreatePeriodModal } from './CreatePeriodModal';

interface TopBarProps {
  user: UserType | null;
  onLogout: () => void;
  periods: PayrollPeriod[];
  selectedPeriodId: number | null;
  onSelectPeriod: (id: number) => void;
  onPeriodCreated?: (newPeriodId: number) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  user,
  onLogout,
  periods,
  selectedPeriodId,
  onSelectPeriod,
  onPeriodCreated
}) => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleCreated = (id: number) => {
    if (onPeriodCreated) onPeriodCreated(id);
    else onSelectPeriod(id);
  };

  return (
    <header className="top-bar">
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#334155', fontWeight: 600, fontSize: '13.5px' }}>
          <Calendar size={18} color="#1e3a8a" />
          <span>Payroll Period:</span>
        </div>
        <select
          value={selectedPeriodId || ''}
          onChange={(e) => onSelectPeriod(Number(e.target.value))}
          className="form-input"
          style={{ width: 'auto', padding: '6px 12px', fontWeight: 600, color: '#1e3a8a' }}
        >
          {periods.map(p => (
            <option key={p.id} value={p.id}>
              {p.month_name} {p.year} ({p.status})
            </option>
          ))}
          {periods.length === 0 && <option value="">No Periods Created</option>}
        </select>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="btn btn-secondary btn-sm"
          style={{ padding: '5px 10px', fontSize: '12px', borderColor: '#cbd5e1' }}
          title="Create a new payroll period for any month"
        >
          <Plus size={13} color="#1e3a8a" />
          <span>New Month</span>
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#059669', background: '#ecfdf5', padding: '4px 10px', borderRadius: '999px', border: '1px solid #a7f3d0' }}>
          <Activity size={12} />
          <span>Active Plant Database Connected</span>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {user ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '13px', fontWeight: 700, color: '#0f172a' }}>{user.fullName}</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '4px' }}>
                <Shield size={10} color="#64748b" />
                <span style={{ fontSize: '11px', color: '#64748b' }}>{user.role}</span>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="btn btn-secondary btn-sm"
              title="Sign Out"
              style={{ padding: '6px 10px' }}
            >
              <LogOut size={15} />
              <span>Logout</span>
            </button>
          </div>
        ) : null}
      </div>

      <CreatePeriodModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onPeriodCreated={handleCreated}
      />
    </header>
  );
};
