export interface User {
  id: number;
  username: string;
  fullName: string;
  role: 'Super Administrator' | 'Payroll Administrator' | 'Payroll Operator' | 'Approver / Auditor' | 'Read-Only User';
}

export interface Designation {
  id: number;
  name: string;
  alias: string;
  is_active: boolean;
  rate_id?: number;
  gross_salary_rate?: number;
  special_allowance?: number;
  thermal_allowance?: number;
  perf_allowance_default?: number;
  effective_from?: string;
  employee_count?: number;
}

export interface Contractor {
  id: number;
  name: string;
  code?: string;
  contact_person?: string;
  phone?: string;
  employee_count?: number;
}

export interface Circle {
  id: number;
  name: string;
  code?: string;
  employee_count?: number;
}

export interface Department {
  id: number;
  circle_id?: number;
  circle_name?: string;
  name: string;
  code?: string;
  employee_count?: number;
}

export interface PayrollRuleSet {
  id: number;
  name: string;
  is_active: boolean;
  epf_wage_cap: number;
  epf_employer_rate: number;
  epf_max_cap: number;
  epf_admin_rate: number;
  epf_admin_max_cap: number;
  epf_employee_rate: number;
  esi_threshold: number;
  esi_employer_rate: number;
  esi_employee_rate: number;
  employer_lwf: number;
  employee_lwf: number;
  thermal_allowance_base: number;
  created_at?: string;
}

export interface Employee {
  id: number;
  emp_code: string;
  sr_no?: string;
  name: string;
  father_name?: string;
  uan?: string;
  designation_id?: number;
  designation_name?: string;
  designation_alias?: string;
  dob?: string;
  age_above_58?: string;
  date_of_joining?: string;
  more_than_3_yrs?: string;
  more_than_5_yrs?: string;
  qualification?: string;
  experience_years?: string;
  qualified_status?: string;
  contractor_id?: number;
  contractor_name?: string;
  circle_id?: number;
  circle_name?: string;
  department_id?: number;
  department_name?: string;
  hazard_duty?: string;
  above_60?: string;
  check_status?: string;
  bank_account?: string;
  ifsc?: string;
  esi_number?: string;
  aadhar_number?: string;
  pan_number?: string;
  is_active: boolean;
  created_at: string;
}

export interface PayrollPeriod {
  id: number;
  year: number;
  month: number;
  month_name: string;
  total_days: number;
  status: 'Draft' | 'Calculated' | 'Under Review' | 'Approved' | 'Finalized';
  notes?: string;
  employee_count?: number;
  total_net_payable?: number;
  total_employer_cost?: number;
  finalized_at?: string;
}

export interface PayrollEntry {
  id: number;
  payroll_period_id: number;
  employee_id: number;
  emp_code: string;
  emp_name: string;
  father_name?: string;
  uan?: string;
  designation_alias?: string;
  contractor_name?: string;
  circle_name?: string;
  department_name?: string;
  bank_account?: string;
  ifsc?: string;
  esi_number?: string;
  present_days: number;
  period_total_days?: number;
  gross_salary_rate: number;
  proportioned_salary: number;
  special_allowance: number;
  total_basic: number;
  thermal_allowance: number;
  perf_allowance_monthly: number;
  perf_allowance_days: number;
  total_earnings_before_bonus: number;
  bonus: number;
  employer_epf_12: number;
  employer_epf_1: number;
  employer_esi_325: number;
  employer_lwf: number;
  gross_total: number;
  employee_epf_12: number;
  employee_esi_075: number;
  employee_lwf: number;
  total_employee_deductions: number;
  total_employer_contributions: number;
  combined_deductions: number;
  net_payable: number;
  is_overridden: boolean;
  calculation_mode: string;
}

export interface DashboardEmployeeItem {
  id: number;
  name: string;
  emp_code: string;
  uan?: string;
  bank_account?: string;
  ifsc?: string;
  esi_number?: string;
  designation_alias: string;
  designation_name: string;
  contractor_id?: number;
  contractor_name: string;
  circle_id?: number;
  circle_name: string;
  present_days: number;
  gross_salary_rate: number;
  total_basic: number;
  thermal_allowance: number;
  perf_allowance_days: number;
  bonus: number;
  total_earnings_before_bonus: number;
  employee_epf_12: number;
  employee_esi_075: number;
  employee_lwf: number;
  total_employee_deductions: number;
  net_payable: number;
}

export interface CircleWorkforceStats {
  circleName: string;
  totalCount: number;
  totalNetPayable: number;
  totalBasic: number;
  totalGross: number;
  employees: DashboardEmployeeItem[];
}

export interface DashboardStats {
  employeeOverview: {
    total: number;
    active: number;
    inactive: number;
    missing_bank: number;
    missing_uan: number;
    missing_esi: number;
  };
  employeesByDesignation: Array<{
    designation: string;
    alias?: string;
    count: number;
    employees?: DashboardEmployeeItem[];
  }>;
  employeesByContractor: Array<{
    id?: number;
    contractor: string;
    count: number;
    totalNetPayable?: number;
    employees?: DashboardEmployeeItem[];
  }>;
  employeesByCircle: Array<{ circle: string; count: number }>;
  circleWorkforce?: {
    emc: CircleWorkforceStats;
    mm1: CircleWorkforceStats;
  };
  payrollStats: {
    periodId: number | null;
    periodName: string;
    status: string;
    totalEmployeesPaid: number;
    totalGrossEarnings: number;
    totalEmployerEpf12: number;
    totalEmployerEpf1: number;
    totalEmployerEsi325: number;
    totalEmployerLwf: number;
    totalEmployeeEpf: number;
    totalEmployeeEsi: number;
    totalEmployeeDeductions: number;
    totalCombinedDeductions: number;
    totalNetPayable: number;
    totalEmployerCost: number;
  };
  recentActivity: Array<{
    user_name: string;
    action: string;
    entity_type: string;
    details: string;
    created_at: string;
  }>;
}

export interface ReconciliationReport {
  timestamp: string;
  referenceFile: string;
  overall: {
    totalEmployeesAudited: number;
    totalEmployeesMatched: number;
    overallMatchRate: string;
    status: string;
  };
  sheets: {
    [key: string]: {
      totalChecked: number;
      totalMatched: number;
      mismatches: number;
      matchRate: string;
      sampleComparisons: Array<{
        row: number;
        empCode: string;
        empName: string;
        designation: string;
        attendance: string;
        softwareNetPayable: number;
        excelNetPayable: number;
        diff: number;
        status: string;
        breakdown: any;
      }>;
    };
  };
}
