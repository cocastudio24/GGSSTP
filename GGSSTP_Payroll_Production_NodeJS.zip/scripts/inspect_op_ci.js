const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY OP AND c&i.xlsx');
try {
  const workbook = XLSX.readFile(filePath, { cellFormula: true });
  console.log('SALARY OP AND c&i.xlsx Sheets:', workbook.SheetNames);
  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    console.log(`Sheet: ${sheetName}, range: ${sheet['!ref']}`);
  }
} catch (e) {
  console.error('Error reading SALARY OP AND c&i:', e.message);
}
