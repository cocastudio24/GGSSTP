const XLSX = require('xlsx');
const path = require('path');
const workbook = XLSX.readFile(path.join(__dirname, '../reference_files/SALARY OP AND c&i.xlsx'), { cellFormula: true });
const sheet = workbook.Sheets['operation circle'];
const range = XLSX.utils.decode_range(sheet['!ref']);
console.log(`operation circle cols: ${range.e.c + 1}, rows: ${range.e.r + 1}`);
for (let c = 0; c <= range.e.c; c++) {
  const colLetter = XLSX.utils.encode_col(c);
  const h1 = sheet[XLSX.utils.encode_cell({ r: 0, c })]?.v || '';
  const h2 = sheet[XLSX.utils.encode_cell({ r: 1, c })]?.v || '';
  const val = sheet[XLSX.utils.encode_cell({ r: 2, c })]?.v || '';
  const f = sheet[XLSX.utils.encode_cell({ r: 2, c })]?.f || '';
  console.log(`Col ${colLetter}: h1="${h1}", h2="${h2}" => val="${val}" ${f ? `formula="=${f}"` : ''}`);
}
