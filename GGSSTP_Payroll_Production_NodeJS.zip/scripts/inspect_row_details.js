const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

function inspectSheetRows(sheetName) {
  const sheet = workbook.Sheets[sheetName];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  console.log(`\n======================================================`);
  console.log(`INSPECTING ALL ROWS IN: ${sheetName} (Max Row: ${range.e.r + 1})`);

  let countWithData = 0;
  for (let r = 0; r <= range.e.r; r++) {
    const rowVals = [];
    for (let c = 0; c <= Math.min(10, range.e.c); c++) {
      const cell = sheet[XLSX.utils.encode_cell({ r, c })];
      if (cell && cell.v !== undefined) {
        rowVals.push(`Col${c}:${cell.v}`);
      }
    }
    if (rowVals.length > 0) {
      countWithData++;
      if (r < 25 || r > range.e.r - 10 || r === 45 || r === 46) {
        console.log(`Row ${r + 1}: ${rowVals.slice(0, 5).join(' | ')}`);
      }
    }
  }
  console.log(`Total rows with data: ${countWithData}`);
}

inspectSheetRows('MM-1');
inspectSheetRows('EMC');
