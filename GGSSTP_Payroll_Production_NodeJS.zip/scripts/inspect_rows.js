const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

function inspectRows(sheetName, startRow, empCodeCol, nameCol) {
  const sheet = workbook.Sheets[sheetName];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  console.log(`\n==================================================`);
  console.log(`INSPECTING ROWS FOR: ${sheetName}`);
  
  let validEmployees = 0;
  let formulaDiscrepancies = [];
  let summaryRows = [];

  for (let r = startRow; r <= range.e.r; r++) {
    const codeCell = sheet[XLSX.utils.encode_cell({ r, c: empCodeCol })];
    const nameCell = sheet[XLSX.utils.encode_cell({ r, c: nameCol })];
    const codeVal = codeCell ? String(codeCell.v).trim() : '';
    const nameVal = nameCell ? String(nameCell.v).trim() : '';

    if (!codeVal && !nameVal) {
      // Check if any cell has value
      let hasAnyVal = false;
      for (let c = range.s.c; c <= range.e.c; c++) {
        const cell = sheet[XLSX.utils.encode_cell({ r, c })];
        if (cell && cell.v !== undefined && String(cell.v).trim() !== '') {
          hasAnyVal = true;
          break;
        }
      }
      if (hasAnyVal) {
        summaryRows.push({ row: r + 1, desc: 'Non-empty row without code/name' });
      }
      continue;
    }

    if (codeVal.toLowerCase().includes('total') || nameVal.toLowerCase().includes('total')) {
      summaryRows.push({ row: r + 1, codeVal, nameVal });
      continue;
    }

    validEmployees++;
  }

  console.log(`Total valid employee rows found: ${validEmployees}`);
  console.log(`Summary or other rows:`, summaryRows);
}

inspectRows('MM-1', 1, 0, 1); // Row 2 is index 1, col A=0, col B=1
inspectRows('EMC', 2, 0, 4);  // Row 3 is index 2, col A=0 (Sr No), col E=4 (Name)
