const fs = require('fs');
const path = require('path');
const { ZipArchive } = require('archiver');

const rootDir = path.resolve(__dirname, '..');
const zipFile = path.join(rootDir, 'GGSSTP_Payroll_Production_NodeJS.zip');

console.log('1. Preparing archive output stream...');
if (fs.existsSync(zipFile)) {
  fs.unlinkSync(zipFile);
}

const output = fs.createWriteStream(zipFile);
const archive = new ZipArchive({
  zlib: { level: 9 },
  forceLocalTime: true,
  forceZip64: false
});

output.on('close', function () {
  const stats = fs.statSync(zipFile);
  console.log('================================================================');
  console.log('✅ 100% HEALTHY STANDARD ZIP ARCHIVE GENERATED SUCCESSFULLY!');
  console.log(`Path: ${zipFile}`);
  console.log(`Total Bytes: ${archive.pointer()} (${(stats.size / (1024 * 1024)).toFixed(2)} MB)`);
  console.log('================================================================');
});

archive.on('warning', function (err) {
  if (err.code === 'ENOENT') {
    console.warn(err);
  } else {
    throw err;
  }
});

archive.on('error', function (err) {
  console.error('Archive error:', err);
  throw err;
});

archive.pipe(output);

console.log('2. Appending files and directories to zip...');

// Root configuration & documentation files
const rootFiles = [
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  '.env',
  '.env.example',
  'Dockerfile',
  'docker-compose.yml',
  'cloudbuild.yaml',
  '.dockerignore',
  'README.md',
  'FORMULA_AUDIT_REPORT.md',
  'HOW_TO_RUN_ON_SERVER.txt',
  'start_ggsstp.bat'
];

for (const file of rootFiles) {
  const p = path.join(rootDir, file);
  if (fs.existsSync(p)) {
    archive.file(p, { name: file });
  }
}

// Add dist folder (compiled backend)
archive.directory(path.join(rootDir, 'dist'), 'dist');

// Add src folder (backend source code)
archive.directory(path.join(rootDir, 'src'), 'src');

// Add reference_files folder
archive.directory(path.join(rootDir, 'reference_files'), 'reference_files');

// Add client folder (compiled dist + source files, strictly excluding node_modules)
archive.directory(path.join(rootDir, 'client', 'dist'), 'client/dist');
archive.directory(path.join(rootDir, 'client', 'src'), 'client/src');
if (fs.existsSync(path.join(rootDir, 'client', 'public'))) {
  archive.directory(path.join(rootDir, 'client', 'public'), 'client/public');
}
const clientFiles = [
  'index.html',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'tsconfig.node.json',
  'vite.config.ts'
];
for (const cf of clientFiles) {
  const cp = path.join(rootDir, 'client', cf);
  if (fs.existsSync(cp)) {
    archive.file(cp, { name: `client/${cf}` });
  }
}

// Add useful scripts
const scriptsToInclude = ['package_zip.js', 'test_suite.js', 'verify_formulas.js'];
for (const s of scriptsToInclude) {
  const sp = path.join(rootDir, 'scripts', s);
  if (fs.existsSync(sp)) {
    archive.file(sp, { name: `scripts/${s}` });
  }
}

console.log('3. Finalizing standard zip archive...');
archive.finalize();
