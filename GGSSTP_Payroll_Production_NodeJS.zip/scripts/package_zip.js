const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const stageDir = path.join(rootDir, '_staging_pkg');
const zipFile = path.join(rootDir, 'GGSSTP_Payroll_Production_NodeJS.zip');

console.log('1. Preparing staging environment...');
if (fs.existsSync(stageDir)) fs.rmSync(stageDir, { recursive: true, force: true });
if (fs.existsSync(zipFile)) fs.rmSync(zipFile, { force: true });

fs.mkdirSync(stageDir, { recursive: true });

function copyRecursive(src, dest) {
  if (!fs.existsSync(src)) return;
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const item of fs.readdirSync(src)) {
      if (
        item === 'node_modules' ||
        item === '.git' ||
        item === '.gemini' ||
        item === 'ggsstp_pg' ||
        item === '_staging_pkg' ||
        item.endsWith('.zip')
      ) {
        continue;
      }
      copyRecursive(path.join(src, item), path.join(dest, item));
    }
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

console.log('2. Staging production files & pre-compiled builds...');

// Root files
const rootFiles = [
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  '.env',
  '.env.example',
  'Dockerfile',
  'docker-compose.yml',
  'cloudbuild.yaml',
  '.dockerignore',
  'README.md',
  'FORMULA_AUDIT_REPORT.md',
  'HOW_TO_RUN_ON_SERVER.txt',
  'start_ggsstp.bat'
];

for (const file of rootFiles) {
  const p = path.join(rootDir, file);
  if (fs.existsSync(p)) {
    fs.copyFileSync(p, path.join(stageDir, file));
  }
}

// Folders
const folders = ['dist', 'src', 'reference_files', 'scripts'];
for (const f of folders) {
  copyRecursive(path.join(rootDir, f), path.join(stageDir, f));
}

// Client folder (excluding client/node_modules)
fs.mkdirSync(path.join(stageDir, 'client'), { recursive: true });
const clientItems = [
  'dist',
  'src',
  'public',
  'index.html',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'tsconfig.node.json',
  'vite.config.ts'
];

for (const ci of clientItems) {
  copyRecursive(path.join(rootDir, 'client', ci), path.join(stageDir, 'client', ci));
}

// Ensure dist/database/schema.sql exists in staging
if (fs.existsSync(path.join(rootDir, 'src/database/schema.sql'))) {
  fs.mkdirSync(path.join(stageDir, 'dist/database'), { recursive: true });
  fs.copyFileSync(path.join(rootDir, 'src/database/schema.sql'), path.join(stageDir, 'dist/database/schema.sql'));
}

console.log('3. Generating GGSSTP_Payroll_Production_NodeJS.zip archive...');
try {
  execSync(`tar -a -c -f "${zipFile}" *`, { cwd: stageDir, stdio: 'inherit' });
} catch (err) {
  console.error('Tar compression failed, trying PowerShell Compress-Archive fallback...', err.message);
  execSync(`powershell -Command "Compress-Archive -Path '${stageDir}\\*' -DestinationPath '${zipFile}' -Force"`, { stdio: 'inherit' });
}

console.log('4. Cleaning up temporary staging files...');
if (fs.existsSync(stageDir)) {
  fs.rmSync(stageDir, { recursive: true, force: true });
}

if (fs.existsSync(zipFile)) {
  const stats = fs.statSync(zipFile);
  console.log('================================================================');
  console.log('PACKAGE CREATED SUCCESSFULLY!');
  console.log(`File: ${zipFile}`);
  console.log(`Size: ${(stats.size / (1024 * 1024)).toFixed(2)} MB (${stats.size} bytes)`);
  console.log('================================================================');
} else {
  console.error('Error: Zip archive was not created.');
}
