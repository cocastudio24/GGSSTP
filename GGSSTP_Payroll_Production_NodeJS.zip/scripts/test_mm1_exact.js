const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });
const sheet = workbook.Sheets['MM-1'];

let matchCount = 0;
let mismatchCount = 0;

for (let r = 1; r <= 21; r++) {
  const getVal = (col) => {
    const cell = sheet[XLSX.utils.encode_cell({ r, c: col })];
    return cell ? cell.v : null;
  };

  const empCode = getVal(0);
  const desig = getVal(4);
  const totalDays = Number(getVal(25));
  const presentDays = Number(getVal(26));
  const perfMonthly = Number(getVal(32)) || 0;
  const bonus = Number(getVal(35)) || 0;

  // Rates
  const rates = {
    'USW': { gross: 14408, special: 3314 },
    'SEMI SW': { gross: 15395, special: 3541 },
    'SW': { gross: 16530, special: 3802 },
    'HSW': { gross: 17835, special: 4102 }
  };
  const rate = rates[desig] || { gross: 0, special: 0 };
  const proportionedSalary = rate.gross / totalDays * presentDays;
  const totalBasic = Math.round((rate.gross + rate.special) * presentDays / totalDays);
  const thermal = Math.round(1500 * presentDays / totalDays);
  
  // Notice: rows 16+ (index 16 is row 17) in MM-1 use ROUND
  const perfDays = r >= 16 ? Math.round(perfMonthly / totalDays * presentDays) : (perfMonthly / totalDays * presentDays);
  const totalEarnings = totalBasic + thermal + perfDays;

  const empEpf12 = Math.round(proportionedSalary < 25000 ? proportionedSalary * 0.12 : 3000);
  const empEpf1 = Math.round(proportionedSalary < 25000 ? proportionedSalary * 0.01 : 250);
  const empEsi325 = Math.round(totalEarnings < 21000 ? totalEarnings * 0.0325 : 0);
  const lwf = 20;

  const grossTotal = totalEarnings + bonus + empEpf12 + empEpf1 + empEsi325 + lwf;

  const dedEpf12 = empEpf12;
  const dedEsi075 = Math.round(totalEarnings < 21000 ? totalEarnings * 0.0075 : 0);
  const dedLwf = 5;

  const empDeduction = dedEpf12 + dedEsi075 + dedLwf;
  const employerCost = empEpf12 + empEpf1 + empEsi325 + lwf;
  const combinedDed = empDeduction + employerCost;
  const netPayable = grossTotal - combinedDed;

  const sheetNet = Number(getVal(47));
  if (Math.abs(netPayable - sheetNet) < 0.001) {
    matchCount++;
  } else {
    mismatchCount++;
    console.log(`Mismatch on row ${r + 1} (${empCode}): calc ${netPayable} vs sheet ${sheetNet}`);
  }
}

console.log(`MM-1 Result: ${matchCount} matches, ${mismatchCount} mismatches out of 21 employees.`);
