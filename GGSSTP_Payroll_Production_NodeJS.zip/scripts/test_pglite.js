const { PGlite } = require('@electric-sql/pglite');
const path = require('path');
const fs = require('fs');

async function testPG() {
  const dbDir = path.join(__dirname, '../data/test_pg');
  fs.mkdirSync(dbDir, { recursive: true });
  const db = new PGlite(dbDir);
  await db.exec(`
    CREATE TABLE IF NOT EXISTS test_users (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL
    );
    INSERT INTO test_users (name) VALUES ('Test User');
  `);
  const res = await db.query('SELECT * FROM test_users;');
  console.log('PGlite query result:', res.rows);
  await db.close();
  console.log('PGlite test succeeded!');
}

testPG().catch(console.error);
