const { db } = require('../dist/database/db');
const { calculatePayroll, INITIAL_RATES } = require('../dist/engine/payrollCalculator');
const { ExcelImporter } = require('../dist/excel/excelImporter');
const { ExcelExporter } = require('../dist/excel/excelExporter');
const path = require('path');
const fs = require('fs');

async function runTestSuite() {
  console.log('================================================================');
  console.log('STARTING GGSSTP COMPREHENSIVE AUTOMATED TEST SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  // TEST 1: Database Initialization
  console.log('--- TEST GROUP 1: Database Initialization & Seeding ---');
  await db.init();
  const userCheck = await db.query('SELECT COUNT(*) as count FROM users;');
  assert(parseInt(userCheck.rows[0].count) >= 4, 'Users seeded with minimum 4 default accounts (admin, payroll_admin, operator, auditor)');

  const desCheck = await db.query('SELECT alias, gross_salary_rate, special_allowance FROM designations d JOIN designation_salary_rates dsr ON d.id = dsr.designation_id;');
  const desRates = {};
  desCheck.rows.forEach(r => { desRates[r.alias] = { gross: Number(r.gross_salary_rate), special: Number(r.special_allowance) }; });
  
  assert(desRates['USW'] && desRates['USW'].gross === 14408 && desRates['USW'].special === 3314, 'USW rate: ₹14,408 gross, ₹3,314 special allowance');
  assert(desRates['SEMI SW'] && desRates['SEMI SW'].gross === 15395 && desRates['SEMI SW'].special === 3541, 'SEMI SW rate: ₹15,395 gross, ₹3,541 special allowance');
  assert(desRates['SW'] && desRates['SW'].gross === 16530 && desRates['SW'].special === 3802, 'SW rate: ₹16,530 gross, ₹3,802 special allowance');
  assert(desRates['HSW'] && desRates['HSW'].gross === 17835 && desRates['HSW'].special === 4102, 'HSW rate: ₹17,835 gross, ₹4,102 special allowance');

  // TEST 2: Calculation Engine Precision
  console.log('\n--- TEST GROUP 2: Payroll Engine Calculation Precision ---');
  // Full attendance SW (30/30 days, perf: 225, bonus: 0)
  const fullSW = calculatePayroll({
    designationAlias: 'SW',
    totalDays: 30,
    presentDays: 30,
    perfAllowanceMonthly: 225,
    bonus: 0
  });
  assert(fullSW.grossSalaryRate === 16530, 'Full SW Gross Salary is 16530');
  assert(fullSW.totalBasic === 20332, `Full SW Total Basic: (16530 + 3802) = 20332 (got ${fullSW.totalBasic})`);
  assert(fullSW.thermalAllowance === 1500, `Full SW Thermal Allowance is 1500 (got ${fullSW.thermalAllowance})`);
  assert(fullSW.perfAllowanceDaysWise === 225, `Full SW Performance Allowance is 225 (got ${fullSW.perfAllowanceDaysWise})`);
  assert(fullSW.totalEarningsBeforeBonus === 22057, `Full SW Total Earnings: 20332 + 1500 + 225 = 22057 (got ${fullSW.totalEarningsBeforeBonus})`);
  assert(fullSW.employerEpf12 === 1984, `Full SW Employer EPF: ROUND(16530 * 0.12) = 1984 (got ${fullSW.employerEpf12})`);
  assert(fullSW.employerEpf1 === 165, `Full SW Employer EPF 1%: ROUND(16530 * 0.01) = 165 (got ${fullSW.employerEpf1})`);
  assert(fullSW.employerEsi325 === 0, `Full SW Employer ESI: Earnings > 21000 so ESI is 0 (got ${fullSW.employerEsi325})`);
  assert(fullSW.employerLwf === 20, 'Full SW Employer LWF is 20');
  assert(fullSW.employeeEpf12 === 1984, `Full SW Employee EPF Deduction is 1984 (got ${fullSW.employeeEpf12})`);
  assert(fullSW.employeeEsi075 === 0, `Full SW Employee ESI Deduction is 0 (got ${fullSW.employeeEsi075})`);
  assert(fullSW.employeeLwf === 5, 'Full SW Employee LWF Deduction is 5');
  assert(fullSW.totalEmployeeDeductions === 1989, `Full SW Total Employee Deductions: 1984 + 0 + 5 = 1989 (got ${fullSW.totalEmployeeDeductions})`);
  assert(fullSW.netPayable === 20068, `Full SW Net Payable: 22057 - 1989 = 20068 (got ${fullSW.netPayable})`);

  // Partial attendance (7/30 days, SW, MM-1 Row 2 reference employee)
  const partSW = calculatePayroll({
    designationAlias: 'SW',
    totalDays: 30,
    presentDays: 7,
    perfAllowanceMonthly: 225,
    bonus: 0
  });
  assert(partSW.totalBasic === 4744, `Part SW (7 days) Total Basic: 4744 (got ${partSW.totalBasic})`);
  assert(partSW.thermalAllowance === 350, `Part SW (7 days) Thermal: 350 (got ${partSW.thermalAllowance})`);
  assert(partSW.employerEpf12 === 463, `Part SW (7 days) Employer EPF: 463 (got ${partSW.employerEpf12})`);
  assert(partSW.employerEsi325 === 167, `Part SW (7 days) Employer ESI 3.25%: 167 (got ${partSW.employerEsi325})`);
  assert(partSW.employeeEsi075 === 39, `Part SW (7 days) Employee ESI 0.75%: 39 (got ${partSW.employeeEsi075})`);
  assert(partSW.totalEmployeeDeductions === 507, `Part SW (7 days) Total Employee Deductions: 507 (got ${partSW.totalEmployeeDeductions})`);
  assert(partSW.netPayable === 4639.5, `Part SW (7 days) Net Payable: 4639.5 (got ${partSW.netPayable})`);

  // TEST 3: Zero Attendance Boundary Test
  console.log('\n--- TEST GROUP 3: Zero Attendance Boundary Test ---');
  const zeroAtt = calculatePayroll({
    designationAlias: 'USW',
    totalDays: 30,
    presentDays: 0,
    perfAllowanceMonthly: 225,
    bonus: 0
  });
  assert(zeroAtt.totalBasic === 0, 'Zero attendance yields ₹0 Total Basic');
  assert(zeroAtt.thermalAllowance === 0, 'Zero attendance yields ₹0 Thermal Allowance');
  assert(zeroAtt.employerEpf12 === 0, 'Zero attendance yields ₹0 Employer EPF');
  assert(zeroAtt.employeeDeductionsTotal !== undefined || zeroAtt.netPayable === -5, `Zero attendance net payable is ₹-5 (only mandatory ₹5 LWF deduction) (got ${zeroAtt.netPayable})`);

  // TEST 4: Reference Workbook Full Reconciliation
  console.log('\n--- TEST GROUP 4: Full Reconciliation on Uploaded Workbook ---');
  const refPath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  const buffer = fs.readFileSync(refPath);
  const parsedSheets = ExcelImporter.parseWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx');

  assert(parsedSheets['MM-1'] && parsedSheets['MM-1'].length === 21, `MM-1 parsed 21 employees (got ${parsedSheets['MM-1']?.length})`);
  assert(parsedSheets['EMC'] && parsedSheets['EMC'].length === 45, `EMC parsed 45 employees (got ${parsedSheets['EMC']?.length})`);

  // Commit reference data
  const commitRes = await ExcelImporter.commitImport(
    [...(parsedSheets['MM-1'] || []), ...(parsedSheets['EMC'] || [])],
    9, 2026, 'test_suite'
  );
  assert(commitRes.totalRecords === 66, `Total 66 employees committed to database (got ${commitRes.totalRecords})`);

  // TEST 5: Formula-Preserving Excel Export
  console.log('\n--- TEST GROUP 5: Live Formula Excel Export ---');
  const workbook = await ExcelExporter.generatePayrollWorkbook(commitRes.periodId);
  const outPath = path.join(__dirname, '../reference_files/test_export_output.xlsx');
  await workbook.xlsx.writeFile(outPath);
  assert(fs.existsSync(outPath) && fs.statSync(outPath).size > 10000, `Generated formula-preserving Excel file (${fs.statSync(outPath).size} bytes)`);

  // Re-read generated workbook to inspect formulas
  const testWb = new (require('exceljs')).Workbook();
  await testWb.xlsx.readFile(outPath);
  const testSheet = testWb.getWorksheet(1);
  const cellR3 = testSheet.getCell('R3'); // Total Basic formula
  assert(cellR3.value && typeof cellR3.value === 'object' && cellR3.value.formula, `Cell R3 contains live formula: =${cellR3.value?.formula}`);
  const cellAI3 = testSheet.getCell('AI3'); // Net Payable formula
  assert(cellAI3.value && typeof cellAI3.value === 'object' && cellAI3.value.formula, `Cell AI3 contains live formula: =${cellAI3.value?.formula}`);

  console.log('\n================================================================');
  console.log(`TEST SUITE RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTestSuite().catch(err => {
  console.error('Test suite failed with unexpected error:', err);
  process.exit(1);
});
