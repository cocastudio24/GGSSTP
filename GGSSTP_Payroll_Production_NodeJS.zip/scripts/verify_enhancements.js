const http = require('http');

function request(options, data) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(body) });
        } catch {
          resolve({ status: res.statusCode, raw: body });
        }
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(typeof data === 'string' ? data : JSON.stringify(data));
    }
    req.end();
  });
}

async function verifyAllFeatures() {
  console.log('--- Verifying GGSSTP API and Enhancements ---\n');

  // 1. Authenticate as Super Admin
  const loginRes = await request({
    hostname: 'localhost',
    port: 5000,
    path: '/api/auth/login',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, { username: 'admin', password: 'admin@ggsstp2026' });

  console.log('1. Login status:', loginRes.status, loginRes.data?.user?.username);
  const token = loginRes.data.token;
  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  };

  // 2. Test Contractor CRUD (Add, Edit, Delete)
  const addCont = await request({
    hostname: 'localhost', port: 5000, path: '/api/org/contractors', method: 'POST', headers: authHeaders
  }, { name: 'Test Agency XYZ', code: 'TA-99', contact_person: 'Ramesh Singh', phone: '9876543210' });
  console.log('2. Contractor Add:', addCont.status, addCont.data?.contractor?.name);

  const contId = addCont.data.contractor.id;
  const editCont = await request({
    hostname: 'localhost', port: 5000, path: `/api/org/contractors/${contId}`, method: 'PUT', headers: authHeaders
  }, { name: 'Test Agency XYZ Updated', code: 'TA-99B', contact_person: 'Ramesh Kumar', phone: '9876543211' });
  console.log('3. Contractor Edit:', editCont.status, editCont.data?.contractor?.name);

  const delCont = await request({
    hostname: 'localhost', port: 5000, path: `/api/org/contractors/${contId}`, method: 'DELETE', headers: authHeaders
  });
  console.log('4. Contractor Delete:', delCont.status, delCont.data?.message);

  // 3. Test Circle CRUD (Add, Edit, Delete)
  const addCir = await request({
    hostname: 'localhost', port: 5000, path: '/api/org/circles', method: 'POST', headers: authHeaders
  }, { name: 'Test Turbines Circle', code: 'TC-01' });
  console.log('5. Circle Add:', addCir.status, addCir.data?.circle?.name);

  const cirId = addCir.data.circle.id;
  const editCir = await request({
    hostname: 'localhost', port: 5000, path: `/api/org/circles/${cirId}`, method: 'PUT', headers: authHeaders
  }, { name: 'Test Turbines Circle Phase 2', code: 'TC-02' });
  console.log('6. Circle Edit:', editCir.status, editCir.data?.circle?.name);

  const delCir = await request({
    hostname: 'localhost', port: 5000, path: `/api/org/circles/${cirId}`, method: 'DELETE', headers: authHeaders
  });
  console.log('7. Circle Delete:', delCir.status, delCir.data?.message);

  // 4. Test User Management (Add, Edit, Delete)
  const addUsr = await request({
    hostname: 'localhost', port: 5000, path: '/api/users', method: 'POST', headers: authHeaders
  }, { username: 'test_operator_99', fullName: 'Test Operator', role: 'Payroll Operator', password: 'pass@ggsstp123' });
  console.log('8. User Add:', addUsr.status, addUsr.data?.user?.username);

  const usrId = addUsr.data.user.id;
  const editUsr = await request({
    hostname: 'localhost', port: 5000, path: `/api/users/${usrId}`, method: 'PUT', headers: authHeaders
  }, { fullName: 'Test Operator Senior', role: 'Payroll Administrator' });
  console.log('9. User Edit:', editUsr.status, editUsr.data?.user?.full_name, editUsr.data?.user?.role);

  const delUsr = await request({
    hostname: 'localhost', port: 5000, path: `/api/users/${usrId}`, method: 'DELETE', headers: authHeaders
  });
  console.log('10. User Delete:', delUsr.status, delUsr.data?.message);

  // 5. Test Formula & Rules Engine
  const rulesRes = await request({
    hostname: 'localhost', port: 5000, path: '/api/payroll/rules', method: 'GET', headers: authHeaders
  });
  console.log('11. Rules Get:', rulesRes.status, 'Total rules:', rulesRes.data?.rules?.length);

  // 6. Test Period Days & Attendance Batch
  const periodsRes = await request({
    hostname: 'localhost', port: 5000, path: '/api/payroll/periods', method: 'GET', headers: authHeaders
  });
  const periodId = periodsRes.data.periods[0].id;

  const cycleDaysRes = await request({
    hostname: 'localhost', port: 5000, path: `/api/payroll/periods/${periodId}/days`, method: 'PUT', headers: authHeaders
  }, { totalDays: 30 });
  console.log('12. Cycle Days Update:', cycleDaysRes.status, cycleDaysRes.data?.message);

  // 7. Test Entries List
  const entriesRes = await request({
    hostname: 'localhost', port: 5000, path: `/api/payroll/entries?periodId=${periodId}&limit=5`, method: 'GET', headers: authHeaders
  });
  console.log('13. Payroll Entries Get:', entriesRes.status, 'Loaded count:', entriesRes.data?.entries?.length);

  const firstEntry = entriesRes.data.entries[0];
  if (firstEntry) {
    const editEntryRes = await request({
      hostname: 'localhost', port: 5000, path: `/api/payroll/entries/${firstEntry.id}`, method: 'PUT', headers: authHeaders
    }, {
      present_days: 28,
      perf_allowance_monthly: 225,
      bonus: 500
    });
    console.log('14. Full Entry Edit:', editEntryRes.status, 'New Net Payable:', editEntryRes.data?.entry?.net_payable);
  }

  // 8. Test Static Frontend Serving
  const frontendRes = await request({
    hostname: 'localhost', port: 5000, path: '/', method: 'GET'
  });
  console.log('15. Frontend index.html serving:', frontendRes.status, frontendRes.raw?.includes('GGSSTP') ? 'Title matched' : 'Loaded');

  console.log('\n--- ALL VERIFICATION CHECKS COMPLETED SUCCESSFULLY ---');
}

verifyAllFeatures().catch(console.error);
