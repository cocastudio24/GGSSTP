import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { PGlite } from '@electric-sql/pglite';
import { Pool } from 'pg';

export interface DBResult<T = any> {
  rows: T[];
  rowCount?: number;
}

class DatabaseManager {
  private pgliteInstance: PGlite | null = null;
  private pgPool: Pool | null = null;
  private initPromise: Promise<void> | null = null;

  async init(): Promise<void> {
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      const databaseUrl = process.env.DATABASE_URL;
      if (databaseUrl) {
        console.log('Connecting to PostgreSQL via DATABASE_URL...');
        this.pgPool = new Pool({ connectionString: databaseUrl });
      } else {
        const dataDir = path.join(__dirname, '../../data/ggsstp_pg');
        fs.mkdirSync(dataDir, { recursive: true });
        console.log(`Using persistent PGlite PostgreSQL storage at: ${dataDir}`);
        this.pgliteInstance = new PGlite(dataDir);
      }

      await this.applySchema();
      await this.seedInitialData();
      console.log('Database initialized successfully.');
    })();

    return this.initPromise;
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<DBResult<T>> {
    if (!this.initPromise) await this.init();
    else await this.initPromise;

    if (this.pgPool) {
      const result = await this.pgPool.query(sql, params);
      return { rows: result.rows as T[], rowCount: result.rowCount || 0 };
    } else if (this.pgliteInstance) {
      const result = await this.pgliteInstance.query<T>(sql, params);
      return { rows: result.rows, rowCount: result.rows.length };
    }
    throw new Error('Database not initialized');
  }

  async exec(sql: string): Promise<void> {
    if (!this.initPromise) await this.init();
    else await this.initPromise;

    if (this.pgPool) {
      await this.pgPool.query(sql);
    } else if (this.pgliteInstance) {
      await this.pgliteInstance.exec(sql);
    }
  }

  private async rawExec(sql: string): Promise<void> {
    if (this.pgPool) {
      await this.pgPool.query(sql);
    } else if (this.pgliteInstance) {
      await this.pgliteInstance.exec(sql);
    }
  }

  private async rawQuery<T = any>(sql: string, params: any[] = []): Promise<DBResult<T>> {
    if (this.pgPool) {
      const result = await this.pgPool.query(sql, params);
      return { rows: result.rows as T[], rowCount: result.rowCount || 0 };
    } else if (this.pgliteInstance) {
      const result = await this.pgliteInstance.query<T>(sql, params);
      return { rows: result.rows, rowCount: result.rows.length };
    }
    throw new Error('Database not initialized');
  }

  private async applySchema() {
    let schemaPath = path.join(__dirname, 'schema.sql');
    if (!fs.existsSync(schemaPath)) {
      schemaPath = path.join(__dirname, '../../src/database/schema.sql');
    }
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    await this.rawExec(schemaSql);

    // Apply incremental migrations if needed
    try {
      await this.rawExec(`
        ALTER TABLE payroll_rule_sets 
        ADD COLUMN IF NOT EXISTS epf_employee_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.1200;
      `);
    } catch {
      // Ignored if already exists
    }
  }

  private async seedInitialData() {
    // Check if designations exist
    const desCheck = await this.rawQuery('SELECT COUNT(*) as count FROM designations;');
    if (parseInt(desCheck.rows[0].count, 10) === 0) {
      console.log('Seeding initial designations & salary rates...');
      const designations = [
        { name: 'Unskilled', alias: 'USW', gross: 14408, special: 3314 },
        { name: 'Semi Skilled', alias: 'SEMI SW', gross: 15395, special: 3541 },
        { name: 'Skilled', alias: 'SW', gross: 16530, special: 3802 },
        { name: 'Highly Skilled', alias: 'HSW', gross: 17835, special: 4102 }
      ];

      for (const d of designations) {
        const desRes = await this.rawQuery(
          `INSERT INTO designations (name, alias) VALUES ($1, $2) RETURNING id;`,
          [d.name, d.alias]
        );
        const desId = desRes.rows[0].id;
        await this.rawQuery(
          `INSERT INTO designation_salary_rates 
           (designation_id, gross_salary_rate, special_allowance, thermal_allowance, perf_allowance_default)
           VALUES ($1, $2, $3, 1500, 225);`,
          [desId, d.gross, d.special]
        );
      }
    }

    // Check if initial users exist
    const userCheck = await this.rawQuery('SELECT COUNT(*) as count FROM users;');
    if (parseInt(userCheck.rows[0].count, 10) === 0) {
      console.log('Seeding default authorized users...');
      const salt = bcrypt.genSaltSync(10);
      const users = [
        { username: 'admin', name: 'Super Administrator', role: 'Super Administrator', pass: 'admin@ggsstp2026' },
        { username: 'payroll_admin', name: 'Payroll Incharge', role: 'Payroll Administrator', pass: 'payroll@ggsstp2026' },
        { username: 'operator', name: 'Data Entry Operator', role: 'Payroll Operator', pass: 'operator@ggsstp2026' },
        { username: 'auditor', name: 'Accounts Auditor', role: 'Approver / Auditor', pass: 'auditor@ggsstp2026' }
      ];

      for (const u of users) {
        const hash = bcrypt.hashSync(u.pass, salt);
        await this.rawQuery(
          `INSERT INTO users (username, password_hash, full_name, role) VALUES ($1, $2, $3, $4);`,
          [u.username, hash, u.name, u.role]
        );
      }
    }

    // Check if default rule set exists
    const ruleCheck = await this.rawQuery('SELECT COUNT(*) as count FROM payroll_rule_sets;');
    if (parseInt(ruleCheck.rows[0].count, 10) === 0) {
      await this.rawQuery(`
        INSERT INTO payroll_rule_sets 
        (name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate, epf_admin_max_cap,
         esi_threshold, esi_employer_rate, esi_employee_rate, employer_lwf, employee_lwf, thermal_allowance_base)
        VALUES
        ('GGSSTP Reference Rule Set (Sep 2026)', TRUE, 25000, 0.1200, 3000, 0.0100, 250,
         21000, 0.0325, 0.0075, 20.00, 5.00, 1500.00);
      `);
    }
  }
}

export const db = new DatabaseManager();
