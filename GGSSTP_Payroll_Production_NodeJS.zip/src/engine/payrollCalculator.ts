export interface CalculationInput {
  designationAlias: string;
  grossSalaryRate?: number;
  specialAllowanceRate?: number;
  totalDays: number;
  presentDays: number;
  perfAllowanceMonthly?: number;
  bonus?: number;
  isPerfRounded?: boolean; // For MM-1 rows 17-22 compatibility
  mode?: 'Reference-Compatible' | 'Configurable';
  ruleSet?: {
    epfWageCap?: number;
    epfEmployerRate?: number;
    epfMaxCap?: number;
    epfAdminRate?: number;
    epfAdminMaxCap?: number;
    epfEmployeeRate?: number;
    esiThreshold?: number;
    esiEmployerRate?: number;
    esiEmployeeRate?: number;
    employerLwf?: number;
    employeeLwf?: number;
    thermalAllowanceBase?: number;
  };
  customThermalAllowance?: number;
  customEmployeeEpf?: number;
  customEmployeeEsi?: number;
  customEmployeeLwf?: number;
  customEmployerEpf?: number;
  customEmployerEpf1?: number;
  customEmployerEsi?: number;
  customEmployerLwf?: number;
}

export interface CalculationResult {
  grossSalaryRate: number;
  proportionedSalary: number;
  specialAllowance: number;
  totalBasic: number;
  thermalAllowance: number;
  perfAllowanceMonthly: number;
  perfAllowanceDaysWise: number;
  totalEarningsBeforeBonus: number;
  bonus: number;
  employerEpf12: number;
  employerEpf1: number;
  employerEsi325: number;
  employerLwf: number;
  grossTotal: number;
  employeeEpf12: number;
  employeeEsi075: number;
  employeeLwf: number;
  totalEmployeeDeductions: number;
  totalEmployerContributions: number;
  combinedDeductions: number;
  netPayable: number;
  totalEmployerCost: number;
  formulas: {
    proportionedSalary: string;
    totalBasic: string;
    thermalAllowance: string;
    perfAllowanceDaysWise: string;
    totalEarningsBeforeBonus: string;
    employerEpf12: string;
    employerEpf1: string;
    employerEsi325: string;
    grossTotal: string;
    employeeEpf12: string;
    employeeEsi075: string;
    totalEmployeeDeductions: string;
    netPayable: string;
  };
}

export const INITIAL_RATES: Record<string, { gross: number; special: number }> = {
  'USW': { gross: 14408, special: 3314 },
  'SEMI SW': { gross: 15395, special: 3541 },
  'SW': { gross: 16530, special: 3802 },
  'HSW': { gross: 17835, special: 4102 }
};

export function calculatePayroll(input: CalculationInput): CalculationResult {
  const mode = input.mode || 'Reference-Compatible';
  const totalDays = Number(input.totalDays) || 0;
  const presentDays = Number(input.presentDays) || 0;

  // Safe check
  if (totalDays <= 0 || presentDays < 0) {
    throw new Error('Total calendar/payroll days must be greater than zero, and present days cannot be negative.');
  }

  // Designation wage rates
  const aliasNorm = (input.designationAlias || '').trim().toUpperCase();
  const defaultRate = INITIAL_RATES[aliasNorm] || { gross: 0, special: 0 };

  const grossSalaryRate = input.grossSalaryRate !== undefined && input.grossSalaryRate !== null
    ? Number(input.grossSalaryRate)
    : defaultRate.gross;

  const specialAllowance = input.specialAllowanceRate !== undefined && input.specialAllowanceRate !== null
    ? Number(input.specialAllowanceRate)
    : defaultRate.special;

  const thermalBase = input.ruleSet?.thermalAllowanceBase ?? 1500;
  const perfMonthly = Number(input.perfAllowanceMonthly) || 0;
  const bonus = Number(input.bonus) || 0;

  // 1. Proportioned Salary = Gross Salary Rate / Total Days * Present Days
  const proportionedSalary = (grossSalaryRate / totalDays) * presentDays;

  // 2. Total Basic = ROUND((Gross Salary + Special Allowance) * Present Days / Total Days, 0)
  const totalBasic = Math.round(((grossSalaryRate + specialAllowance) * presentDays) / totalDays);

  // 3. Thermal Allowance = ROUND(ThermalBase * Present Days / Total Days, 0)
  const thermalAllowance = input.customThermalAllowance !== undefined && input.customThermalAllowance !== null
    ? Number(input.customThermalAllowance)
    : Math.round((thermalBase * presentDays) / totalDays);

  // 4. Performance Allowance Days wise
  let perfAllowanceDaysWise = (perfMonthly / totalDays) * presentDays;
  if (input.isPerfRounded) {
    perfAllowanceDaysWise = Math.round(perfAllowanceDaysWise);
  }

  // 5. Total (Earnings before bonus) = Total Basic + Thermal + Performance Days wise
  const totalEarningsBeforeBonus = totalBasic + thermalAllowance + perfAllowanceDaysWise;

  // Rules
  const epfWageCap = input.ruleSet?.epfWageCap ?? 25000;
  const epfEmployerRate = input.ruleSet?.epfEmployerRate ?? 0.12;
  const epfMaxCap = input.ruleSet?.epfMaxCap ?? 3000;
  const epfAdminRate = input.ruleSet?.epfAdminRate ?? 0.01;
  const epfAdminMaxCap = input.ruleSet?.epfAdminMaxCap ?? 250;
  const epfEmployeeRate = input.ruleSet?.epfEmployeeRate ?? epfEmployerRate;

  const esiThreshold = input.ruleSet?.esiThreshold ?? 21000;
  const esiEmployerRate = input.ruleSet?.esiEmployerRate ?? 0.0325;
  const esiEmployeeRate = input.ruleSet?.esiEmployeeRate ?? 0.0075;

  const defaultEmployerLwf = input.ruleSet?.employerLwf ?? 20;
  const defaultEmployeeLwf = input.ruleSet?.employeeLwf ?? 5;

  // 6. Employer EPF 12% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.12, 3000), 0)
  const employerEpf12 = input.customEmployerEpf !== undefined && input.customEmployerEpf !== null
    ? Number(input.customEmployerEpf)
    : Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfEmployerRate : epfMaxCap);

  // 7. Employer EPF 1% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.01, 250), 0)
  const employerEpf1 = input.customEmployerEpf1 !== undefined && input.customEmployerEpf1 !== null
    ? Number(input.customEmployerEpf1)
    : Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfAdminRate : epfAdminMaxCap);

  // 8. Employer ESI 3.25% = ROUND(IF(TotalEarnings < 21000, TotalEarnings * 0.0325, 0), 0)
  const employerEsi325 = input.customEmployerEsi !== undefined && input.customEmployerEsi !== null
    ? Number(input.customEmployerEsi)
    : Math.round(totalEarningsBeforeBonus < esiThreshold ? totalEarningsBeforeBonus * esiEmployerRate : 0);

  // 9. Employer LWF
  const employerLwf = input.customEmployerLwf !== undefined && input.customEmployerLwf !== null
    ? Number(input.customEmployerLwf)
    : defaultEmployerLwf;

  // 10. Gross Total (Source formula = SUM(EarningsBeforeBonus + Bonus + all 4 Employer Contributions))
  const grossTotal = totalEarningsBeforeBonus + bonus + employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // 11. Employee EPF 12%
  const employeeEpf12 = input.customEmployeeEpf !== undefined && input.customEmployeeEpf !== null
    ? Number(input.customEmployeeEpf)
    : (input.ruleSet?.epfEmployeeRate
        ? Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfEmployeeRate : epfMaxCap)
        : employerEpf12);

  // 12. Employee ESI 0.75% = ROUND(IF(TotalEarnings < 21000, TotalEarnings * 0.0075, 0), 0)
  const employeeEsi075 = input.customEmployeeEsi !== undefined && input.customEmployeeEsi !== null
    ? Number(input.customEmployeeEsi)
    : Math.round(totalEarningsBeforeBonus < esiThreshold ? totalEarningsBeforeBonus * esiEmployeeRate : 0);

  // 13. Employee LWF
  const employeeLwf = input.customEmployeeLwf !== undefined && input.customEmployeeLwf !== null
    ? Number(input.customEmployeeLwf)
    : defaultEmployeeLwf;

  // 12. Employee Total Deductions = Employee EPF + Employee ESI + Employee LWF
  const totalEmployeeDeductions = employeeEpf12 + employeeEsi075 + employeeLwf;

  // 13. Employer Cost Total = Employer EPF 12% + EPF 1% + ESI 3.25% + Employer LWF
  const totalEmployerContributions = employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // 14. Combined Deductions (Col AU/AX in Excel) = Employee Deductions + Employer Contributions
  const combinedDeductions = totalEmployeeDeductions + totalEmployerContributions;

  // 15. Net Payable Salary = Gross Total - Combined Deductions
  const netPayable = grossTotal - combinedDeductions;

  // Total Employer Cost to Company (CTC) = Total Employee Earnings + Bonus + Employer Contributions
  const totalEmployerCost = totalEarningsBeforeBonus + bonus + totalEmployerContributions;

  return {
    grossSalaryRate,
    proportionedSalary,
    specialAllowance,
    totalBasic,
    thermalAllowance,
    perfAllowanceMonthly: perfMonthly,
    perfAllowanceDaysWise,
    totalEarningsBeforeBonus,
    bonus,
    employerEpf12,
    employerEpf1,
    employerEsi325,
    employerLwf,
    grossTotal,
    employeeEpf12,
    employeeEsi075,
    employeeLwf,
    totalEmployeeDeductions,
    totalEmployerContributions,
    combinedDeductions,
    netPayable,
    totalEmployerCost,
    formulas: {
      proportionedSalary: `GrossSalaryRate / TotalDays * PresentDays`,
      totalBasic: `ROUND((GrossSalaryRate + SpecialAllowance) * PresentDays / TotalDays, 0)`,
      thermalAllowance: `ROUND(${thermalBase} * PresentDays / TotalDays, 0)`,
      perfAllowanceDaysWise: `PerfMonthly / TotalDays * PresentDays`,
      totalEarningsBeforeBonus: `TotalBasic + ThermalAllowance + ProratedPerfAllowance`,
      employerEpf12: `ROUND(IF(ProportionedSalary < ${epfWageCap}, ProportionedSalary * ${epfEmployerRate}, ${epfMaxCap}), 0)`,
      employerEpf1: `ROUND(IF(ProportionedSalary < ${epfWageCap}, ProportionedSalary * ${epfAdminRate}, ${epfAdminMaxCap}), 0)`,
      employerEsi325: `ROUND(IF(TotalEarnings < ${esiThreshold}, TotalEarnings * ${esiEmployerRate}, 0), 0)`,
      grossTotal: `TotalEarnings + Bonus + EmployerEPF12 + EmployerEPF1 + EmployerESI + EmployerLWF`,
      employeeEpf12: `EmployerEPF12`,
      employeeEsi075: `ROUND(IF(TotalEarnings < ${esiThreshold}, TotalEarnings * ${esiEmployeeRate}, 0), 0)`,
      totalEmployeeDeductions: `EmployeeEPF12 + EmployeeESI + EmployeeLWF`,
      netPayable: `GrossTotal - CombinedDeductions = (TotalEarnings + Bonus) - TotalEmployeeDeductions`
    }
  };
}
