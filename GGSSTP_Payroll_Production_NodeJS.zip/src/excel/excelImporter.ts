import XLSX from 'xlsx';
import { db } from '../database/db';
import { calculatePayroll, INITIAL_RATES } from '../engine/payrollCalculator';

export interface ParsedEmployeeRow {
  empCode: string;
  srNo?: string;
  name: string;
  fatherName?: string;
  uan?: string;
  designationAlias: string;
  dob?: string;
  ageAbove58?: string;
  dateOfJoining?: string;
  moreThan3Yrs?: string;
  moreThan5Yrs?: string;
  qualification?: string;
  experienceYears?: string;
  qualifiedStatus?: string;
  contractorName?: string;
  circleName?: string;
  departmentName?: string;
  hazardDuty?: string;
  above60?: string;
  checkStatus?: string;
  bankAccount?: string;
  ifsc?: string;
  esiNumber?: string;
  aadharNumber?: string;
  panNumber?: string;
  totalDays: number;
  presentDays: number;
  perfAllowanceMonthly: number;
  bonus: number;
  sourceSheet: string;
  sourceRow: number;
  isPerfRounded?: boolean;
}

export interface ImportPreviewResult {
  fileName: string;
  sheetName: string;
  detectedLayout: string;
  totalRecords: number;
  previewRows: ParsedEmployeeRow[];
  duplicates: string[];
  warnings: string[];
}

export class ExcelImporter {
  static parseWorkbook(buffer: Buffer, fileName: string): Record<string, ParsedEmployeeRow[]> {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    const results: Record<string, ParsedEmployeeRow[]> = {};

    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      if (!sheet || !sheet['!ref']) continue;

      const rows = this.parseSheet(sheet, sheetName);
      if (rows.length > 0) {
        results[sheetName] = rows;
      }
    }

    return results;
  }

  static parseSheet(sheet: XLSX.WorkSheet, sheetName: string): ParsedEmployeeRow[] {
    const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
    const getVal = (r: number, c: number) => {
      const cell = sheet[XLSX.utils.encode_cell({ r, c })];
      return cell ? cell.v : null;
    };

    const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim() : '');
    const cleanNum = (val: any) => {
      if (val === null || val === undefined) return 0;
      const num = Number(val);
      return isNaN(num) ? 0 : num;
    };

    const rows: ParsedEmployeeRow[] = [];

    // Check layout:
    // Layout 1: MM-1 style (Row 1 headers: Emp Code in Col A)
    const row0A = cleanStr(getVal(0, 0)).toLowerCase();
    const row1A = cleanStr(getVal(1, 0)).toLowerCase();

    const isMM1 = row0A.includes('emp code') || sheetName.toUpperCase().includes('MM');
    const isEMC = (row0A.includes('contractor') || row1A.includes('sr no')) && sheetName.toUpperCase().includes('EMC');
    const isOpCircle = sheetName.toLowerCase().includes('operation') || cleanStr(getVal(0, 0)).toLowerCase().includes('operation');

    if (isMM1) {
      for (let r = 1; r <= range.e.r; r++) {
        const empCode = cleanStr(getVal(r, 0));
        const name = cleanStr(getVal(r, 1));
        if (!empCode && !name) continue;
        if (empCode.toLowerCase().includes('total') || name.toLowerCase().includes('total')) continue;

        let desig = cleanStr(getVal(r, 4)).toUpperCase();
        if (desig === 'SEMI-SW') desig = 'SEMI SW';

        const c5Val = cleanStr(getVal(r, 5));
        let dob = '';
        let ageAbove58 = 'N';
        let dateOfJoining = '';
        let moreThan3Yrs = 'NO';
        let moreThan5Yrs = 'NO';
        let qualification = '';
        let experienceYears = '';
        let qualifiedStatus = '';
        let contractorName = '';
        let hazardDuty = '';

        if (c5Val === 'N' || c5Val === 'Y') {
          // Row where DOB was omitted and fields shifted left by 1 column
          dob = '';
          ageAbove58 = c5Val;
          dateOfJoining = cleanStr(getVal(r, 6));
          moreThan3Yrs = cleanStr(getVal(r, 7));
          moreThan5Yrs = cleanStr(getVal(r, 8));
          qualification = cleanStr(getVal(r, 9));
          experienceYears = cleanStr(getVal(r, 10));
          qualifiedStatus = cleanStr(getVal(r, 11));
          contractorName = cleanStr(getVal(r, 12));
          hazardDuty = cleanStr(getVal(r, 13));
        } else {
          dob = c5Val;
          ageAbove58 = cleanStr(getVal(r, 6)) || 'N';
          dateOfJoining = cleanStr(getVal(r, 7));
          moreThan3Yrs = cleanStr(getVal(r, 8));
          moreThan5Yrs = cleanStr(getVal(r, 9));
          qualification = cleanStr(getVal(r, 10));
          experienceYears = cleanStr(getVal(r, 11));
          qualifiedStatus = cleanStr(getVal(r, 12));
          contractorName = cleanStr(getVal(r, 13));
          hazardDuty = cleanStr(getVal(r, 14));
        }

        rows.push({
          empCode: empCode || `EMP-${100 + r}`,
          name,
          fatherName: cleanStr(getVal(r, 2)),
          uan: cleanStr(getVal(r, 3)),
          designationAlias: desig || 'SW',
          dob,
          ageAbove58,
          dateOfJoining,
          moreThan3Yrs,
          moreThan5Yrs,
          qualification,
          experienceYears,
          qualifiedStatus,
          contractorName,
          hazardDuty,
          above60: cleanStr(getVal(r, 15)),
          checkStatus: cleanStr(getVal(r, 17)),
          bankAccount: cleanStr(getVal(r, 18)),
          ifsc: cleanStr(getVal(r, 19)),
          esiNumber: cleanStr(getVal(r, 20)),
          circleName: 'MM-1 CIRCLE',
          departmentName: 'MM-1 CELL',
          totalDays: cleanNum(getVal(r, 25)) || 30,
          presentDays: cleanNum(getVal(r, 26)),
          perfAllowanceMonthly: cleanNum(getVal(r, 32)),
          bonus: cleanNum(getVal(r, 35)),
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: r >= 16 // rows 17-22 in MM-1 use ROUND
        });
      }
    } else if (isEMC) {
      for (let r = 2; r <= range.e.r; r++) {
        const srNo = cleanStr(getVal(r, 0));
        const refNo = cleanStr(getVal(r, 1));
        const name = cleanStr(getVal(r, 4));
        if (!name && !srNo) continue;
        if (name.toLowerCase().includes('total')) continue;

        let desig = cleanStr(getVal(r, 7)).toUpperCase();
        if (desig === 'SEMI-SW') desig = 'SEMI SW';

        rows.push({
          empCode: `EMC-${refNo || srNo || r}`,
          srNo: srNo || refNo,
          name,
          fatherName: cleanStr(getVal(r, 5)),
          uan: cleanStr(getVal(r, 6)),
          designationAlias: desig || 'SW',
          dob: cleanStr(getVal(r, 8)),
          ageAbove58: cleanStr(getVal(r, 9)),
          dateOfJoining: cleanStr(getVal(r, 10)),
          moreThan3Yrs: cleanStr(getVal(r, 11)),
          moreThan5Yrs: cleanStr(getVal(r, 12)),
          qualification: cleanStr(getVal(r, 13)),
          experienceYears: cleanStr(getVal(r, 14)),
          qualifiedStatus: cleanStr(getVal(r, 15)),
          contractorName: cleanStr(getVal(r, 16)),
          hazardDuty: cleanStr(getVal(r, 17)),
          above60: cleanStr(getVal(r, 18)),
          checkStatus: cleanStr(getVal(r, 20)),
          bankAccount: cleanStr(getVal(r, 21)),
          ifsc: cleanStr(getVal(r, 22)),
          esiNumber: cleanStr(getVal(r, 23)),
          circleName: cleanStr(getVal(r, 2)) || 'EMC CIRCLE',
          departmentName: cleanStr(getVal(r, 3)) || 'EM-3',
          totalDays: cleanNum(getVal(r, 28)) || 30,
          presentDays: cleanNum(getVal(r, 29)),
          perfAllowanceMonthly: cleanNum(getVal(r, 35)),
          bonus: cleanNum(getVal(r, 38)),
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: false
        });
      }
    } else {
      // General / Operation circle layout: inspect row 1 or 2
      const startR = isOpCircle ? 2 : 1;
      for (let r = startR; r <= range.e.r; r++) {
        const srNo = cleanStr(getVal(r, 0));
        const name = cleanStr(getVal(r, isOpCircle ? 2 : 1));
        if (!name && !srNo) continue;
        if (name.toLowerCase().includes('total')) continue;

        let desig = cleanStr(getVal(r, isOpCircle ? 4 : 4)).toUpperCase();
        if (desig === 'SEMI-SW') desig = 'SEMI SW';

        rows.push({
          empCode: cleanStr(getVal(r, isOpCircle ? 6 : 0)) || `EMP-${sheetName}-${r}`,
          srNo,
          name,
          fatherName: cleanStr(getVal(r, isOpCircle ? 3 : 2)),
          uan: cleanStr(getVal(r, isOpCircle ? 6 : 3)),
          designationAlias: desig || 'SW',
          dob: cleanStr(getVal(r, isOpCircle ? 5 : 5)),
          bankAccount: cleanStr(getVal(r, isOpCircle ? 11 : 18)),
          ifsc: cleanStr(getVal(r, isOpCircle ? 12 : 19)),
          esiNumber: cleanStr(getVal(r, isOpCircle ? 7 : 20)),
          aadharNumber: cleanStr(getVal(r, isOpCircle ? 8 : 21)),
          panNumber: cleanStr(getVal(r, isOpCircle ? 9 : 22)),
          contractorName: cleanStr(getVal(r, isOpCircle ? 1 : 13)),
          circleName: isOpCircle ? 'OPERATION CIRCLE' : `${sheetName} CIRCLE`,
          departmentName: isOpCircle ? cleanStr(getVal(r, 1)) : 'MAIN',
          dateOfJoining: cleanStr(getVal(r, isOpCircle ? 13 : 7)),
          totalDays: cleanNum(getVal(r, isOpCircle ? 16 : 25)) || 30,
          presentDays: cleanNum(getVal(r, isOpCircle ? 17 : 26)),
          perfAllowanceMonthly: cleanNum(getVal(r, isOpCircle ? 23 : 32)),
          bonus: cleanNum(getVal(r, isOpCircle ? 26 : 35)),
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: false
        });
      }
    }

    return rows;
  }

  static async commitImport(rows: ParsedEmployeeRow[], payrollMonth: number, payrollYear: number, userName: string) {
    // 1. Get or create payroll period
    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[payrollMonth] || 'September';

    let periodRes = await db.query(
      `SELECT id FROM payroll_periods WHERE year = $1 AND month = $2;`,
      [payrollYear, payrollMonth]
    );

    let periodId: number;
    if (periodRes.rows.length === 0) {
      const newPeriod = await db.query(
        `INSERT INTO payroll_periods (year, month, month_name, total_days, status) 
         VALUES ($1, $2, $3, 30, 'Draft') RETURNING id;`,
        [payrollYear, payrollMonth, monthName]
      );
      periodId = newPeriod.rows[0].id;
    } else {
      periodId = periodRes.rows[0].id;
    }

    // Cache designations
    const desRows = await db.query(`SELECT id, alias FROM designations;`);
    const desMap = new Map<string, number>();
    desRows.rows.forEach(d => desMap.set(d.alias.toUpperCase(), d.id));

    let createdCount = 0;
    let updatedCount = 0;

    for (const r of rows) {
      // 1. Contractor
      let contractorId: number | null = null;
      if (r.contractorName) {
        const cRes = await db.query(`SELECT id FROM contractors WHERE name = $1;`, [r.contractorName]);
        if (cRes.rows.length > 0) {
          contractorId = cRes.rows[0].id;
        } else {
          const newC = await db.query(`INSERT INTO contractors (name) VALUES ($1) RETURNING id;`, [r.contractorName]);
          contractorId = newC.rows[0].id;
        }
      }

      // 2. Circle
      let circleId: number | null = null;
      if (r.circleName) {
        const cirRes = await db.query(`SELECT id FROM circles WHERE name = $1;`, [r.circleName]);
        if (cirRes.rows.length > 0) {
          circleId = cirRes.rows[0].id;
        } else {
          const newCir = await db.query(`INSERT INTO circles (name) VALUES ($1) RETURNING id;`, [r.circleName]);
          circleId = newCir.rows[0].id;
        }
      }

      // 3. Department
      let deptId: number | null = null;
      if (r.departmentName) {
        const dRes = await db.query(`SELECT id FROM departments WHERE name = $1 AND circle_id = $2;`, [r.departmentName, circleId]);
        if (dRes.rows.length > 0) {
          deptId = dRes.rows[0].id;
        } else {
          const newDept = await db.query(`INSERT INTO departments (name, circle_id) VALUES ($1, $2) RETURNING id;`, [r.departmentName, circleId]);
          deptId = newDept.rows[0].id;
        }
      }

      // 4. Designation
      let desigId = desMap.get(r.designationAlias.toUpperCase()) || desMap.get('SW') || 3;

      // 5. Upsert Employee
      let empId: number;
      const empRes = await db.query(`SELECT id FROM employees WHERE emp_code = $1;`, [r.empCode]);
      if (empRes.rows.length > 0) {
        empId = empRes.rows[0].id;
        await db.query(`
          UPDATE employees SET
            sr_no = $1, name = $2, father_name = $3, uan = $4, designation_id = $5,
            dob = $6, age_above_58 = $7, date_of_joining = $8, more_than_3_yrs = $9,
            more_than_5_yrs = $10, qualification = $11, experience_years = $12, qualified_status = $13,
            contractor_id = $14, circle_id = $15, department_id = $16, hazard_duty = $17,
            above_60 = $18, check_status = $19, bank_account = $20, ifsc = $21, esi_number = $22,
            aadhar_number = $23, pan_number = $24, updated_at = CURRENT_TIMESTAMP
          WHERE id = $25;
        `, [
          r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.moreThan3Yrs || 'NO',
          r.moreThan5Yrs || 'NO', r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.hazardDuty || '', r.above60 || '', r.checkStatus || '',
          r.bankAccount || '', r.ifsc || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || '',
          empId
        ]);
        updatedCount++;
      } else {
        const newEmp = await db.query(`
          INSERT INTO employees (
            emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
            date_of_joining, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
            qualified_status, contractor_id, circle_id, department_id, hazard_duty, above_60,
            check_status, bank_account, ifsc, esi_number, aadhar_number, pan_number
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25)
          RETURNING id;
        `, [
          r.empCode, r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.moreThan3Yrs || 'NO',
          r.moreThan5Yrs || 'NO', r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.hazardDuty || '', r.above60 || '', r.checkStatus || '',
          r.bankAccount || '', r.ifsc || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || ''
        ]);
        empId = newEmp.rows[0].id;
        createdCount++;
      }

      // 6. Calculate Payroll for this row
      const calc = calculatePayroll({
        designationAlias: r.designationAlias,
        totalDays: r.totalDays,
        presentDays: r.presentDays,
        perfAllowanceMonthly: r.perfAllowanceMonthly,
        bonus: r.bonus,
        isPerfRounded: r.isPerfRounded
      });

      // 7. Upsert Payroll Entry
      await db.query(`
        INSERT INTO payroll_entries (
          payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
          special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
          total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
          employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
          total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
          calculation_mode
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
          $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
          $21, $22, $23, $24, 'Reference-Compatible'
        )
        ON CONFLICT (payroll_period_id, employee_id) DO UPDATE SET
          present_days = EXCLUDED.present_days,
          gross_salary_rate = EXCLUDED.gross_salary_rate,
          proportioned_salary = EXCLUDED.proportioned_salary,
          special_allowance = EXCLUDED.special_allowance,
          total_basic = EXCLUDED.total_basic,
          thermal_allowance = EXCLUDED.thermal_allowance,
          perf_allowance_monthly = EXCLUDED.perf_allowance_monthly,
          perf_allowance_days = EXCLUDED.perf_allowance_days,
          total_earnings_before_bonus = EXCLUDED.total_earnings_before_bonus,
          bonus = EXCLUDED.bonus,
          employer_epf_12 = EXCLUDED.employer_epf_12,
          employer_epf_1 = EXCLUDED.employer_epf_1,
          employer_esi_325 = EXCLUDED.employer_esi_325,
          employer_lwf = EXCLUDED.employer_lwf,
          gross_total = EXCLUDED.gross_total,
          employee_epf_12 = EXCLUDED.employee_epf_12,
          employee_esi_075 = EXCLUDED.employee_esi_075,
          employee_lwf = EXCLUDED.employee_lwf,
          total_employee_deductions = EXCLUDED.total_employee_deductions,
          total_employer_contributions = EXCLUDED.total_employer_contributions,
          combined_deductions = EXCLUDED.combined_deductions,
          net_payable = EXCLUDED.net_payable,
          updated_at = CURRENT_TIMESTAMP;
      `, [
        periodId, empId, r.presentDays, calc.grossSalaryRate, calc.proportionedSalary,
        calc.specialAllowance, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceMonthly,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable
      ]);
    }

    // 8. Audit log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'IMPORT_EXCEL', 'PAYROLL_PERIOD', $2, $3);
    `, [userName, String(periodId), `Imported ${rows.length} records. Created: ${createdCount}, Updated: ${updatedCount}`]);

    return { periodId, createdCount, updatedCount, totalRecords: rows.length };
  }
}
