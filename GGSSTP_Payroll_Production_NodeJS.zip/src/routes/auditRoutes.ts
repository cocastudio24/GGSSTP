import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

// GET /api/audit-logs
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { action, entityType, limit = 100 } = req.query;
    let query = `SELECT * FROM audit_logs WHERE 1=1`;
    const params: any[] = [];
    let idx = 1;

    if (action) {
      query += ` AND action = $${idx++}`;
      params.push(String(action));
    }
    if (entityType) {
      query += ` AND entity_type = $${idx++}`;
      params.push(String(entityType));
    }

    query += ` ORDER BY created_at DESC LIMIT $${idx++};`;
    params.push(Math.min(500, Number(limit) || 100));

    const result = await db.query(query, params);
    res.json({ logs: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
