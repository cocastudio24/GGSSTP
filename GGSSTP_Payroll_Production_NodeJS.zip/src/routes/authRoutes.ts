import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../database/db';
import { generateToken, authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const userRes = await db.query(
      `SELECT id, username, password_hash, full_name, role, is_active FROM users WHERE username = $1;`,
      [username.trim()]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const user = userRes.rows[0];
    if (!user.is_active) {
      return res.status(403).json({ error: 'User account is deactivated. Contact administrator.' });
    }

    const match = bcrypt.compareSync(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const authUser = {
      id: user.id,
      username: user.username,
      fullName: user.full_name,
      role: user.role
    };

    const token = generateToken(authUser);

    await db.query(
      `INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
       VALUES ($1, 'USER_LOGIN', 'USER', $2, 'User logged in successfully');`,
      [user.username, String(user.id)]
    );

    res.json({ token, user: authUser });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: err.message || 'Internal server error during login' });
  }
});

router.get('/me', authMiddleware, (req: AuthRequest, res) => {
  res.json({ user: req.user });
});

export default router;
