import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.get('/stats', authMiddleware, async (req, res) => {
  try {
    const periodIdQuery = req.query.periodId ? Number(req.query.periodId) : null;

    // 1. Employee overview counts
    const empCountsRes = await db.query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN is_active = TRUE THEN 1 END) as active,
        COUNT(CASE WHEN is_active = FALSE THEN 1 END) as inactive,
        COUNT(CASE WHEN bank_account IS NULL OR bank_account = '' THEN 1 END) as missing_bank,
        COUNT(CASE WHEN uan IS NULL OR uan = '' THEN 1 END) as missing_uan,
        COUNT(CASE WHEN esi_number IS NULL OR esi_number = '' THEN 1 END) as missing_esi
      FROM employees;
    `);

    // 2. Active or selected payroll period
    let periodRow: any = null;
    if (periodIdQuery) {
      const pRes = await db.query(`SELECT * FROM payroll_periods WHERE id = $1;`, [periodIdQuery]);
      if (pRes.rows.length > 0) periodRow = pRes.rows[0];
    } else {
      const pRes = await db.query(`SELECT * FROM payroll_periods ORDER BY year DESC, month DESC LIMIT 1;`);
      if (pRes.rows.length > 0) periodRow = pRes.rows[0];
    }

    // 3. Query all working employees with their live payroll entries, circles, contractors, and designations
    // Sorted strictly alphabetically by employee name (e.name ASC)
    const allEmployeesRes = await db.query(`
      SELECT 
        e.id, e.name, e.emp_code, e.uan, e.bank_account, e.ifsc, e.esi_number,
        COALESCE(d.alias, 'SW') as designation_alias, 
        COALESCE(d.name, 'Skilled') as designation_name,
        c.id as contractor_id, 
        COALESCE(c.name, 'Direct / Unassigned') as contractor_name,
        cir.id as circle_id, 
        COALESCE(cir.name, 'General Circle') as circle_name,
        COALESCE(pe.present_days, 0) as present_days,
        COALESCE(pe.gross_salary_rate, 0) as gross_salary_rate,
        COALESCE(pe.total_basic, 0) as total_basic,
        COALESCE(pe.thermal_allowance, 0) as thermal_allowance,
        COALESCE(pe.perf_allowance_days, 0) as perf_allowance_days,
        COALESCE(pe.bonus, 0) as bonus,
        COALESCE(pe.total_earnings_before_bonus, 0) as total_earnings_before_bonus,
        COALESCE(pe.employee_epf_12, 0) as employee_epf_12,
        COALESCE(pe.employee_esi_075, 0) as employee_esi_075,
        COALESCE(pe.employee_lwf, 0) as employee_lwf,
        COALESCE(pe.total_employee_deductions, 0) as total_employee_deductions,
        COALESCE(pe.net_payable, 0) as net_payable
      FROM employees e
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN payroll_entries pe ON pe.employee_id = e.id ${periodRow ? 'AND pe.payroll_period_id = ' + periodRow.id : ''}
      WHERE e.is_active = TRUE
      ORDER BY e.name ASC;
    `);

    const allEmployees = allEmployeesRes.rows;

    // 4. Detailed Circle breakdowns for EMC Circle and MM-1 Circle
    const emcEmployees = allEmployees.filter(e => e.circle_name && e.circle_name.toUpperCase().includes('EMC'));
    const mm1Employees = allEmployees.filter(e => e.circle_name && e.circle_name.toUpperCase().includes('MM-1'));

    const circleWorkforce = {
      emc: {
        circleName: 'EMC Circle',
        totalCount: emcEmployees.length,
        totalNetPayable: emcEmployees.reduce((acc, curr) => acc + Number(curr.net_payable || 0), 0),
        totalBasic: emcEmployees.reduce((acc, curr) => acc + Number(curr.total_basic || 0), 0),
        totalGross: emcEmployees.reduce((acc, curr) => acc + (Number(curr.total_earnings_before_bonus || 0) + Number(curr.bonus || 0)), 0),
        employees: emcEmployees // Sorted alphabetically by employee name
      },
      mm1: {
        circleName: 'MM-1 Circle',
        totalCount: mm1Employees.length,
        totalNetPayable: mm1Employees.reduce((acc, curr) => acc + Number(curr.net_payable || 0), 0),
        totalBasic: mm1Employees.reduce((acc, curr) => acc + Number(curr.total_basic || 0), 0),
        totalGross: mm1Employees.reduce((acc, curr) => acc + (Number(curr.total_earnings_before_bonus || 0) + Number(curr.bonus || 0)), 0),
        employees: mm1Employees // Sorted alphabetically by employee name
      }
    };

    // 5. Employees by Designation (with employees list sorted alphabetically by name)
    const designationMap: { [key: string]: { designation: string; alias: string; count: number; employees: any[] } } = {};
    for (const emp of allEmployees) {
      const desName = emp.designation_name || 'Unassigned';
      if (!designationMap[desName]) {
        designationMap[desName] = {
          designation: desName,
          alias: emp.designation_alias || 'SW',
          count: 0,
          employees: []
        };
      }
      designationMap[desName].count++;
      designationMap[desName].employees.push(emp);
    }
    const employeesByDesignation = Object.values(designationMap).sort((a, b) => b.count - a.count);

    // 6. Employees by Contractor (with employees list sorted alphabetically by name)
    const contractorMap: { [key: string]: { id: number; contractor: string; count: number; totalNetPayable: number; employees: any[] } } = {};
    for (const emp of allEmployees) {
      const cName = emp.contractor_name || 'Direct / Others';
      if (!contractorMap[cName]) {
        contractorMap[cName] = {
          id: emp.contractor_id || 0,
          contractor: cName,
          count: 0,
          totalNetPayable: 0,
          employees: []
        };
      }
      contractorMap[cName].count++;
      contractorMap[cName].totalNetPayable += Number(emp.net_payable || 0);
      contractorMap[cName].employees.push(emp);
    }
    const employeesByContractor = Object.values(contractorMap).sort((a, b) => b.count - a.count);

    // 7. Circles summary list
    const circleRes = await db.query(`
      SELECT COALESCE(cir.name, 'General Circle') as circle, COUNT(e.id) as count
      FROM employees e
      LEFT JOIN circles cir ON e.circle_id = cir.id
      WHERE e.is_active = TRUE
      GROUP BY cir.name
      ORDER BY count DESC;
    `);

    // 8. Overall Payroll Stats
    let payrollStats = {
      periodId: periodRow ? periodRow.id : null,
      periodName: periodRow ? `${periodRow.month_name} ${periodRow.year}` : 'No Period',
      status: periodRow ? periodRow.status : 'None',
      totalEmployeesPaid: 0,
      totalGrossEarnings: 0,
      totalEmployerEpf12: 0,
      totalEmployerEpf1: 0,
      totalEmployerEsi325: 0,
      totalEmployerLwf: 0,
      totalEmployeeEpf: 0,
      totalEmployeeEsi: 0,
      totalEmployeeDeductions: 0,
      totalCombinedDeductions: 0,
      totalNetPayable: 0,
      totalEmployerCost: 0
    };

    if (periodRow) {
      const pStatsRes = await db.query(`
        SELECT 
          COUNT(*) as total_entries,
          COALESCE(SUM(total_earnings_before_bonus + bonus), 0) as gross_earnings,
          COALESCE(SUM(employer_epf_12), 0) as emp_epf12,
          COALESCE(SUM(employer_epf_1), 0) as emp_epf1,
          COALESCE(SUM(employer_esi_325), 0) as emp_esi325,
          COALESCE(SUM(employer_lwf), 0) as emp_lwf,
          COALESCE(SUM(employee_epf_12), 0) as ded_epf12,
          COALESCE(SUM(employee_esi_075), 0) as ded_esi075,
          COALESCE(SUM(total_employee_deductions), 0) as employee_deductions,
          COALESCE(SUM(total_employer_contributions), 0) as employer_contributions,
          COALESCE(SUM(combined_deductions), 0) as combined_deductions,
          COALESCE(SUM(net_payable), 0) as net_payable
        FROM payroll_entries
        WHERE payroll_period_id = $1;
      `, [periodRow.id]);

      const ps = pStatsRes.rows[0];
      payrollStats.totalEmployeesPaid = Number(ps.total_entries) || 0;
      payrollStats.totalGrossEarnings = Number(ps.gross_earnings) || 0;
      payrollStats.totalEmployerEpf12 = Number(ps.emp_epf12) || 0;
      payrollStats.totalEmployerEpf1 = Number(ps.emp_epf1) || 0;
      payrollStats.totalEmployerEsi325 = Number(ps.emp_esi325) || 0;
      payrollStats.totalEmployerLwf = Number(ps.emp_lwf) || 0;
      payrollStats.totalEmployeeEpf = Number(ps.ded_epf12) || 0;
      payrollStats.totalEmployeeEsi = Number(ps.ded_esi075) || 0;
      payrollStats.totalEmployeeDeductions = Number(ps.employee_deductions) || 0;
      payrollStats.totalCombinedDeductions = Number(ps.combined_deductions) || 0;
      payrollStats.totalNetPayable = Number(ps.net_payable) || 0;
      payrollStats.totalEmployerCost = payrollStats.totalGrossEarnings + Number(ps.employer_contributions);
    }

    // 9. Recent audit activity
    const auditRes = await db.query(`
      SELECT user_name, action, entity_type, details, created_at
      FROM audit_logs
      ORDER BY created_at DESC
      LIMIT 6;
    `);

    res.json({
      employeeOverview: empCountsRes.rows[0],
      employeesByDesignation,
      employeesByContractor,
      employeesByCircle: circleRes.rows,
      circleWorkforce,
      payrollStats,
      recentActivity: auditRes.rows
    });
  } catch (err: any) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: err.message || 'Failed to fetch dashboard stats' });
  }
});

export default router;
