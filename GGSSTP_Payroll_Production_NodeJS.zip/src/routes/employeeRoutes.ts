import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// GET /api/employees
router.get('/', authMiddleware, async (req, res) => {
  try {
    const { search, designationId, contractorId, circleId, status, page = 1, limit = 50 } = req.query;

    let query = `
      SELECT 
        e.*,
        d.name as designation_name, d.alias as designation_alias,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE 1=1
    `;
    const params: any[] = [];
    let pIdx = 1;

    if (search) {
      query += ` AND (e.name ILIKE $${pIdx} OR e.emp_code ILIKE $${pIdx} OR e.uan ILIKE $${pIdx} OR e.bank_account ILIKE $${pIdx})`;
      params.push(`%${String(search).trim()}%`);
      pIdx++;
    }

    if (designationId) {
      query += ` AND e.designation_id = $${pIdx}`;
      params.push(Number(designationId));
      pIdx++;
    }

    if (contractorId) {
      query += ` AND e.contractor_id = $${pIdx}`;
      params.push(Number(contractorId));
      pIdx++;
    }

    if (circleId) {
      query += ` AND e.circle_id = $${pIdx}`;
      params.push(Number(circleId));
      pIdx++;
    }

    if (status === 'active') {
      query += ` AND e.is_active = TRUE`;
    } else if (status === 'inactive') {
      query += ` AND e.is_active = FALSE`;
    }

    query += ` ORDER BY e.id ASC`;

    // Pagination
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.max(1, Number(limit) || 50);
    const offset = (pageNum - 1) * limitNum;

    // Count
    const countRes = await db.query(`SELECT COUNT(*) as total FROM (${query}) sub;`, params);
    const total = Number(countRes.rows[0].total) || 0;

    query += ` LIMIT $${pIdx} OFFSET $${pIdx + 1}`;
    params.push(limitNum, offset);

    const result = await db.query(query, params);

    res.json({
      employees: result.rows,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    console.error('Error fetching employees:', err);
    res.status(500).json({ error: err.message || 'Failed to fetch employees' });
  }
});

// GET /api/employees/:id
router.get('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await db.query(`
      SELECT 
        e.*,
        d.name as designation_name, d.alias as designation_alias,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE e.id = $1;
    `, [Number(id)]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });
    res.json({ employee: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const data = req.body;
    if (!data.name || !data.emp_code) {
      return res.status(400).json({ error: 'Employee Name and Employee Code are required' });
    }

    // Check duplicate code
    const dupCheck = await db.query(`SELECT id FROM employees WHERE emp_code = $1;`, [data.emp_code.trim()]);
    if (dupCheck.rows.length > 0) {
      return res.status(409).json({ error: `Employee Code "${data.emp_code}" already exists.` });
    }

    const insRes = await db.query(`
      INSERT INTO employees (
        emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
        date_of_joining, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
        qualified_status, contractor_id, circle_id, department_id, hazard_duty, above_60,
        check_status, bank_account, ifsc, esi_number, aadhar_number, pan_number, is_active
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)
      RETURNING *;
    `, [
      data.emp_code.trim(), data.sr_no || '', data.name.trim(), data.father_name || '', data.uan || '',
      data.designation_id || null, data.dob || '', data.age_above_58 || 'N', data.date_of_joining || '',
      data.more_than_3_yrs || 'NO', data.more_than_5_yrs || 'NO', data.qualification || '',
      data.experience_years || '', data.qualified_status || '', data.contractor_id || null,
      data.circle_id || null, data.department_id || null, data.hazard_duty || '', data.above_60 || '',
      data.check_status || '', data.bank_account || '', data.ifsc || '', data.esi_number || '',
      data.aadhar_number || '', data.pan_number || '', data.is_active !== false
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_EMPLOYEE', 'EMPLOYEE', $2, $3);
    `, [req.user?.username || 'admin', String(insRes.rows[0].id), `Created employee ${data.name} (${data.emp_code})`]);

    res.status(201).json({ employee: insRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/employees/:id
router.put('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const data = req.body;

    const updRes = await db.query(`
      UPDATE employees SET
        emp_code = COALESCE($1, emp_code),
        sr_no = COALESCE($2, sr_no),
        name = COALESCE($3, name),
        father_name = COALESCE($4, father_name),
        uan = COALESCE($5, uan),
        designation_id = $6,
        dob = COALESCE($7, dob),
        age_above_58 = COALESCE($8, age_above_58),
        date_of_joining = COALESCE($9, date_of_joining),
        more_than_3_yrs = COALESCE($10, more_than_3_yrs),
        more_than_5_yrs = COALESCE($11, more_than_5_yrs),
        qualification = COALESCE($12, qualification),
        experience_years = COALESCE($13, experience_years),
        qualified_status = COALESCE($14, qualified_status),
        contractor_id = $15,
        circle_id = $16,
        department_id = $17,
        hazard_duty = COALESCE($18, hazard_duty),
        above_60 = COALESCE($19, above_60),
        check_status = COALESCE($20, check_status),
        bank_account = COALESCE($21, bank_account),
        ifsc = COALESCE($22, ifsc),
        esi_number = COALESCE($23, esi_number),
        aadhar_number = COALESCE($24, aadhar_number),
        pan_number = COALESCE($25, pan_number),
        is_active = COALESCE($26, is_active),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $27
      RETURNING *;
    `, [
      data.emp_code, data.sr_no, data.name, data.father_name, data.uan,
      data.designation_id, data.dob, data.age_above_58, data.date_of_joining,
      data.more_than_3_yrs, data.more_than_5_yrs, data.qualification, data.experience_years,
      data.qualified_status, data.contractor_id, data.circle_id, data.department_id,
      data.hazard_duty, data.above_60, data.check_status, data.bank_account,
      data.ifsc, data.esi_number, data.aadhar_number, data.pan_number,
      data.is_active, Number(id)
    ]);

    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_EMPLOYEE', 'EMPLOYEE', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Updated employee ${updRes.rows[0].name}`]);

    res.json({ employee: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/employees/:id (Soft delete / deactivate)
router.delete('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const updRes = await db.query(`
      UPDATE employees SET is_active = FALSE, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 RETURNING *;
    `, [Number(id)]);

    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DEACTIVATE_EMPLOYEE', 'EMPLOYEE', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Deactivated employee ${updRes.rows[0].name}`]);

    res.json({ message: 'Employee deactivated successfully', employee: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/bulk-update
router.post('/bulk-update', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { ids, designation_id, contractor_id, is_active } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }

    let updates: string[] = [];
    let params: any[] = [];
    let idx = 1;

    if (designation_id !== undefined) {
      updates.push(`designation_id = $${idx++}`);
      params.push(Number(designation_id));
    }
    if (contractor_id !== undefined) {
      updates.push(`contractor_id = $${idx++}`);
      params.push(Number(contractor_id));
    }
    if (is_active !== undefined) {
      updates.push(`is_active = $${idx++}`);
      params.push(Boolean(is_active));
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update provided' });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    const idPlaceholders = ids.map(() => `$${idx++}`).join(',');
    params.push(...ids);

    const query = `UPDATE employees SET ${updates.join(', ')} WHERE id IN (${idPlaceholders});`;
    await db.query(query, params);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'BULK_UPDATE_EMPLOYEES', 'EMPLOYEE', 'BULK', $2);
    `, [req.user?.username || 'admin', `Bulk updated ${ids.length} employees`]);

    res.json({ message: `Successfully updated ${ids.length} employees` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
