import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { ExcelImporter } from '../excel/excelImporter';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 } }); // 25MB

// POST /api/import/upload
router.post('/upload', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel (.xlsx, .xls) file' });
    }

    const parsedSheets = ExcelImporter.parseWorkbook(req.file.buffer, req.file.originalname);
    const summary: any[] = [];

    for (const [sheetName, rows] of Object.entries(parsedSheets)) {
      summary.push({
        sheetName,
        totalRows: rows.length,
        samplePreview: rows.slice(0, 5),
        sampleEmployeeCodes: rows.slice(0, 5).map(r => r.empCode)
      });
    }

    res.json({
      fileName: req.file.originalname,
      sheetCount: Object.keys(parsedSheets).length,
      sheets: summary,
      parsedData: parsedSheets
    });
  } catch (err: any) {
    console.error('Import upload error:', err);
    res.status(500).json({ error: err.message || 'Failed to parse Excel file' });
  }
});

// POST /api/import/commit
router.post('/commit', authMiddleware, async (req: AuthRequest, res) => {
  try {
    let { rows, month, year, periodId } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'No rows provided to commit' });
    }

    if (periodId && (!month || !year)) {
      const pRes = await db.query('SELECT month, year FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
      if (pRes.rows.length > 0) {
        month = pRes.rows[0].month;
        year = pRes.rows[0].year;
      }
    }

    month = Number(month) || 9;
    year = Number(year) || 2026;

    const userName = req.user?.username || 'admin';
    const commitResult = await ExcelImporter.commitImport(rows, Number(month), Number(year), userName);

    res.json({
      message: `Successfully imported ${commitResult.totalRecords} records`,
      result: commitResult,
      periodId: commitResult.periodId
    });
  } catch (err: any) {
    console.error('Import commit error:', err);
    res.status(500).json({ error: err.message || 'Failed to commit import records' });
  }
});

// POST /api/import/seed-reference (One-click button to load the reference workbook)
router.post('/seed-reference', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const refPath = path.join(__dirname, '../../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
    if (!fs.existsSync(refPath)) {
      return res.status(404).json({ error: 'Reference workbook file not found on server' });
    }

    const buffer = fs.readFileSync(refPath);
    const parsedSheets = ExcelImporter.parseWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx');

    const allRows = [
      ...(parsedSheets['MM-1'] || []),
      ...(parsedSheets['EMC'] || [])
    ];

    const userName = req.user?.username || 'admin';
    const commitResult = await ExcelImporter.commitImport(allRows, 9, 2026, userName);

    res.json({
      message: `Successfully seeded reference data from MM-1 and EMC worksheets (September 2026)!`,
      totalImported: allRows.length,
      mm1Count: (parsedSheets['MM-1'] || []).length,
      emcCount: (parsedSheets['EMC'] || []).length,
      periodId: commitResult.periodId
    });
  } catch (err: any) {
    console.error('Seed reference error:', err);
    res.status(500).json({ error: err.message || 'Failed to seed reference workbook' });
  }
});

export default router;
