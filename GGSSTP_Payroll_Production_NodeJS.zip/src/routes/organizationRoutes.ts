import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// ==================== CONTRACTORS ====================

// GET /api/org/contractors
router.get('/contractors', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT c.*, 
        (SELECT COUNT(*) FROM employees e WHERE e.contractor_id = c.id AND e.is_active = TRUE) as employee_count
      FROM contractors c
      ORDER BY c.name ASC;
    `);
    res.json({ contractors: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/org/contractors
router.post('/contractors', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { name, code, contact_person, phone } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Contractor Name is required' });

    const check = await db.query('SELECT id FROM contractors WHERE LOWER(name) = LOWER($1);', [name.trim()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Contractor "${name.trim()}" already exists.` });
    }

    const result = await db.query(`
      INSERT INTO contractors (name, code, contact_person, phone)
      VALUES ($1, $2, $3, $4) RETURNING *;
    `, [name.trim(), code || '', contact_person || '', phone || '']);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_CONTRACTOR', 'CONTRACTOR', $2, $3);
    `, [req.user?.username || 'admin', String(result.rows[0].id), `Created contractor ${name.trim()}`]);

    res.status(201).json({ contractor: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/org/contractors/:id
router.put('/contractors/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, code, contact_person, phone } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Contractor Name is required' });

    const check = await db.query('SELECT id FROM contractors WHERE LOWER(name) = LOWER($1) AND id != $2;', [name.trim(), Number(id)]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Contractor name "${name.trim()}" is already in use.` });
    }

    const result = await db.query(`
      UPDATE contractors SET
        name = $1, code = $2, contact_person = $3, phone = $4
      WHERE id = $5
      RETURNING *;
    `, [name.trim(), code || '', contact_person || '', phone || '', Number(id)]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'Contractor not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_CONTRACTOR', 'CONTRACTOR', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Updated contractor ${name.trim()}`]);

    res.json({ contractor: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/org/contractors/:id
router.delete('/contractors/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const empCheck = await db.query('SELECT COUNT(*) as count FROM employees WHERE contractor_id = $1;', [Number(id)]);
    const empCount = parseInt(empCheck.rows[0].count, 10);

    if (empCount > 0) {
      // Reassign to NULL or warn
      const force = req.query.force === 'true';
      if (!force) {
        return res.status(400).json({
          error: `Cannot delete: ${empCount} employees are assigned to this contractor. Pass ?force=true to unassign them automatically.`
        });
      }
      await db.query('UPDATE employees SET contractor_id = NULL WHERE contractor_id = $1;', [Number(id)]);
    }

    const delRes = await db.query('DELETE FROM contractors WHERE id = $1 RETURNING *;', [Number(id)]);
    if (delRes.rows.length === 0) return res.status(404).json({ error: 'Contractor not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DELETE_CONTRACTOR', 'CONTRACTOR', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Deleted contractor ${delRes.rows[0].name}`]);

    res.json({ message: 'Contractor deleted successfully', contractor: delRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== CIRCLES ====================

// GET /api/org/circles
router.get('/circles', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT cir.*, 
        (SELECT COUNT(*) FROM employees e WHERE e.circle_id = cir.id AND e.is_active = TRUE) as employee_count,
        (SELECT COUNT(*) FROM departments d WHERE d.circle_id = cir.id) as department_count
      FROM circles cir
      ORDER BY cir.name ASC;
    `);
    res.json({ circles: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/org/circles
router.post('/circles', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { name, code } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Circle Name is required' });

    const check = await db.query('SELECT id FROM circles WHERE LOWER(name) = LOWER($1);', [name.trim()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Circle "${name.trim()}" already exists.` });
    }

    const result = await db.query(`
      INSERT INTO circles (name, code)
      VALUES ($1, $2) RETURNING *;
    `, [name.trim(), code || '']);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_CIRCLE', 'CIRCLE', $2, $3);
    `, [req.user?.username || 'admin', String(result.rows[0].id), `Created circle ${name.trim()}`]);

    res.status(201).json({ circle: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/org/circles/:id
router.put('/circles/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, code } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Circle Name is required' });

    const check = await db.query('SELECT id FROM circles WHERE LOWER(name) = LOWER($1) AND id != $2;', [name.trim(), Number(id)]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Circle name "${name.trim()}" already exists.` });
    }

    const result = await db.query(`
      UPDATE circles SET name = $1, code = $2 WHERE id = $3 RETURNING *;
    `, [name.trim(), code || '', Number(id)]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'Circle not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_CIRCLE', 'CIRCLE', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Updated circle ${name.trim()}`]);

    res.json({ circle: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/org/circles/:id
router.delete('/circles/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const empCheck = await db.query('SELECT COUNT(*) as count FROM employees WHERE circle_id = $1;', [Number(id)]);
    const empCount = parseInt(empCheck.rows[0].count, 10);

    if (empCount > 0) {
      const force = req.query.force === 'true';
      if (!force) {
        return res.status(400).json({
          error: `Cannot delete: ${empCount} employees are assigned to this circle. Pass ?force=true to unassign them automatically.`
        });
      }
      await db.query('UPDATE employees SET circle_id = NULL WHERE circle_id = $1;', [Number(id)]);
    }

    // Also unassign departments
    await db.query('UPDATE departments SET circle_id = NULL WHERE circle_id = $1;', [Number(id)]);

    const delRes = await db.query('DELETE FROM circles WHERE id = $1 RETURNING *;', [Number(id)]);
    if (delRes.rows.length === 0) return res.status(404).json({ error: 'Circle not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DELETE_CIRCLE', 'CIRCLE', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Deleted circle ${delRes.rows[0].name}`]);

    res.json({ message: 'Circle deleted successfully', circle: delRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== DEPARTMENTS / CELLS ====================

// GET /api/org/departments
router.get('/departments', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT dep.*, cir.name as circle_name,
             (SELECT COUNT(*) FROM employees e WHERE e.department_id = dep.id AND e.is_active = TRUE) as employee_count
      FROM departments dep
      LEFT JOIN circles cir ON dep.circle_id = cir.id
      ORDER BY dep.name ASC;
    `);
    res.json({ departments: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/org/departments
router.post('/departments', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { name, circle_id, code } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Department/Cell Name is required' });

    const result = await db.query(`
      INSERT INTO departments (name, circle_id, code)
      VALUES ($1, $2, $3) RETURNING *;
    `, [name.trim(), circle_id ? Number(circle_id) : null, code || '']);

    res.status(201).json({ department: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/org/departments/:id
router.put('/departments/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, circle_id, code } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Department Name is required' });

    const result = await db.query(`
      UPDATE departments SET name = $1, circle_id = $2, code = $3 WHERE id = $4 RETURNING *;
    `, [name.trim(), circle_id ? Number(circle_id) : null, code || '', Number(id)]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'Department not found' });
    res.json({ department: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/org/departments/:id
router.delete('/departments/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    await db.query('UPDATE employees SET department_id = NULL WHERE department_id = $1;', [Number(id)]);
    const result = await db.query('DELETE FROM departments WHERE id = $1 RETURNING *;', [Number(id)]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Department not found' });
    res.json({ message: 'Department deleted successfully', department: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
