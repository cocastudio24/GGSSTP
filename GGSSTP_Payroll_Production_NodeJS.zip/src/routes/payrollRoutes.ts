import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { calculatePayroll } from '../engine/payrollCalculator';

const router = Router();

// ==================== PAYROLL RULE SETS & FORMULA CONFIGURATION ====================

// GET /api/payroll/rules
router.get('/rules', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`SELECT * FROM payroll_rule_sets ORDER BY id ASC;`);
    res.json({ rules: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/rules
router.post('/rules', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const {
      name, epfWageCap, epfEmployerRate, epfMaxCap, epfAdminRate, epfAdminMaxCap,
      epfEmployeeRate, esiThreshold, esiEmployerRate, esiEmployeeRate,
      employerLwf, employeeLwf, thermalAllowanceBase, isActive
    } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ error: 'Rule set name is required' });

    if (isActive) {
      await db.query(`UPDATE payroll_rule_sets SET is_active = FALSE;`);
    }

    const insRes = await db.query(`
      INSERT INTO payroll_rule_sets (
        name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate,
        epf_admin_max_cap, epf_employee_rate, esi_threshold, esi_employer_rate,
        esi_employee_rate, employer_lwf, employee_lwf, thermal_allowance_base
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
      RETURNING *;
    `, [
      name.trim(), Boolean(isActive), Number(epfWageCap) || 25000,
      Number(epfEmployerRate) || 0.12, Number(epfMaxCap) || 3000,
      Number(epfAdminRate) || 0.01, Number(epfAdminMaxCap) || 250,
      Number(epfEmployeeRate) || 0.12, Number(esiThreshold) || 21000,
      Number(esiEmployerRate) || 0.0325, Number(esiEmployeeRate) || 0.0075,
      Number(employerLwf) || 20, Number(employeeLwf) || 5,
      Number(thermalAllowanceBase) || 1500
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_PAYROLL_RULE_SET', 'RULE_SET', $2, $3);
    `, [req.user?.username || 'admin', String(insRes.rows[0].id), `Created rule set "${name.trim()}"`]);

    res.status(201).json({ rule: insRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/rules/:id
router.put('/rules/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const {
      name, epfWageCap, epfEmployerRate, epfMaxCap, epfAdminRate, epfAdminMaxCap,
      epfEmployeeRate, esiThreshold, esiEmployerRate, esiEmployeeRate,
      employerLwf, employeeLwf, thermalAllowanceBase, isActive
    } = req.body;

    if (isActive) {
      await db.query(`UPDATE payroll_rule_sets SET is_active = FALSE WHERE id != $1;`, [Number(id)]);
    }

    const updRes = await db.query(`
      UPDATE payroll_rule_sets SET
        name = COALESCE($1, name),
        is_active = COALESCE($2, is_active),
        epf_wage_cap = COALESCE($3, epf_wage_cap),
        epf_employer_rate = COALESCE($4, epf_employer_rate),
        epf_max_cap = COALESCE($5, epf_max_cap),
        epf_admin_rate = COALESCE($6, epf_admin_rate),
        epf_admin_max_cap = COALESCE($7, epf_admin_max_cap),
        epf_employee_rate = COALESCE($8, epf_employee_rate),
        esi_threshold = COALESCE($9, esi_threshold),
        esi_employer_rate = COALESCE($10, esi_employer_rate),
        esi_employee_rate = COALESCE($11, esi_employee_rate),
        employer_lwf = COALESCE($12, employer_lwf),
        employee_lwf = COALESCE($13, employee_lwf),
        thermal_allowance_base = COALESCE($14, thermal_allowance_base)
      WHERE id = $15
      RETURNING *;
    `, [
      name || null, isActive !== undefined ? Boolean(isActive) : null,
      epfWageCap !== undefined ? Number(epfWageCap) : null,
      epfEmployerRate !== undefined ? Number(epfEmployerRate) : null,
      epfMaxCap !== undefined ? Number(epfMaxCap) : null,
      epfAdminRate !== undefined ? Number(epfAdminRate) : null,
      epfAdminMaxCap !== undefined ? Number(epfAdminMaxCap) : null,
      epfEmployeeRate !== undefined ? Number(epfEmployeeRate) : null,
      esiThreshold !== undefined ? Number(esiThreshold) : null,
      esiEmployerRate !== undefined ? Number(esiEmployerRate) : null,
      esiEmployeeRate !== undefined ? Number(esiEmployeeRate) : null,
      employerLwf !== undefined ? Number(employerLwf) : null,
      employeeLwf !== undefined ? Number(employeeLwf) : null,
      thermalAllowanceBase !== undefined ? Number(thermalAllowanceBase) : null,
      Number(id)
    ]);

    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Rule set not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_PAYROLL_RULE_SET', 'RULE_SET', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Updated payroll rule set ${updRes.rows[0].name}`]);

    res.json({ rule: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== PAYROLL PERIODS ====================

// GET /api/payroll/periods
router.get('/periods', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT 
        p.*,
        (SELECT COUNT(*) FROM payroll_entries pe WHERE pe.payroll_period_id = p.id) as employee_count,
        (SELECT COALESCE(SUM(pe.net_payable), 0) FROM payroll_entries pe WHERE pe.payroll_period_id = p.id) as total_net_payable,
        (SELECT COALESCE(SUM(pe.total_earnings_before_bonus + pe.bonus + pe.total_employer_contributions), 0) 
         FROM payroll_entries pe WHERE pe.payroll_period_id = p.id) as total_employer_cost
      FROM payroll_periods p
      ORDER BY p.year DESC, p.month DESC;
    `);
    res.json({ periods: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods
router.post('/periods', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { year, month, totalDays, notes } = req.body;
    if (!year || !month) return res.status(400).json({ error: 'Year and Month are required' });

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const mName = monthNames[Number(month)] || 'Month';

    const check = await db.query(`SELECT id FROM payroll_periods WHERE year = $1 AND month = $2;`, [Number(year), Number(month)]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Payroll period for ${mName} ${year} already exists.` });
    }

    const insRes = await db.query(`
      INSERT INTO payroll_periods (year, month, month_name, total_days, status, notes)
      VALUES ($1, $2, $3, $4, 'Draft', $5)
      RETURNING *;
    `, [Number(year), Number(month), mName, Number(totalDays) || 30, notes || '']);

    const periodId = insRes.rows[0].id;

    // Fetch active rule set
    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    const activeEmps = await db.query(`
      SELECT e.id, d.alias as designation_alias, dsr.gross_salary_rate, dsr.special_allowance, dsr.perf_allowance_default
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE e.is_active = TRUE;
    `);

    for (const emp of activeEmps.rows) {
      const calc = calculatePayroll({
        designationAlias: emp.designation_alias || 'SW',
        grossSalaryRate: emp.gross_salary_rate,
        specialAllowanceRate: emp.special_allowance,
        totalDays: Number(totalDays) || 30,
        presentDays: Number(totalDays) || 30,
        perfAllowanceMonthly: Number(emp.perf_allowance_default) || 225,
        bonus: 0,
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        INSERT INTO payroll_entries (
          payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
          special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
          total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
          employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
          total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
          calculation_mode
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
          $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
          $21, $22, $23, $24, 'Reference-Compatible'
        );
      `, [
        periodId, emp.id, Number(totalDays) || 30, calc.grossSalaryRate, calc.proportionedSalary,
        calc.specialAllowance, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceMonthly,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable
      ]);
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_PAYROLL_PERIOD', 'PAYROLL_PERIOD', $2, $3);
    `, [req.user?.username || 'admin', String(periodId), `Created payroll period ${mName} ${year}`]);

    res.status(201).json({ period: insRes.rows[0], entriesCount: activeEmps.rows.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/periods/:id/days (Update total days in period and recalculate)
router.put('/periods/:id/days', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { totalDays } = req.body;
    if (!totalDays || Number(totalDays) <= 0) {
      return res.status(400).json({ error: 'Total days must be greater than zero' });
    }

    const upd = await db.query('UPDATE payroll_periods SET total_days = $1 WHERE id = $2 RETURNING *;', [Number(totalDays), Number(id)]);
    if (upd.rows.length === 0) return res.status(404).json({ error: 'Period not found' });

    res.json({ period: upd.rows[0], message: `Period total days updated to ${totalDays}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== PAYROLL ENTRIES & COMPREHENSIVE ADJUSTMENTS ====================

// GET /api/payroll/entries
router.get('/entries', authMiddleware, async (req, res) => {
  try {
    const { periodId, designationId, contractorId, circleId, search, page = 1, limit = 100 } = req.query;
    if (!periodId) return res.status(400).json({ error: 'periodId query param is required' });

    let query = `
      SELECT 
        pe.*,
        e.emp_code, e.sr_no, e.name as emp_name, e.father_name, e.uan, e.dob,
        e.date_of_joining, e.qualification, e.experience_years, e.bank_account,
        e.ifsc, e.esi_number,
        d.alias as designation_alias, d.name as designation_name,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name,
        p.total_days as period_total_days, p.status as period_status
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE pe.payroll_period_id = $1
    `;
    const params: any[] = [Number(periodId)];
    let idx = 2;

    if (search) {
      query += ` AND (e.name ILIKE $${idx} OR e.emp_code ILIKE $${idx} OR e.uan ILIKE $${idx} OR e.bank_account ILIKE $${idx})`;
      params.push(`%${String(search).trim()}%`);
      idx++;
    }

    if (designationId) {
      query += ` AND e.designation_id = $${idx++}`;
      params.push(Number(designationId));
    }

    if (contractorId) {
      query += ` AND e.contractor_id = $${idx++}`;
      params.push(Number(contractorId));
    }

    if (circleId) {
      query += ` AND e.circle_id = $${idx++}`;
      params.push(Number(circleId));
    }

    query += ` ORDER BY e.emp_code ASC`;

    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.max(1, Number(limit) || 100);
    const offset = (pageNum - 1) * limitNum;

    const countRes = await db.query(`SELECT COUNT(*) as total FROM (${query}) sub;`, params);
    const total = Number(countRes.rows[0].total) || 0;

    query += ` LIMIT $${idx++} OFFSET $${idx++}`;
    params.push(limitNum, offset);

    const result = await db.query(query, params);

    res.json({
      entries: result.rows,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/entries/:id (Comprehensive adjustment of attendance, allowances, EPF, ESI, LWF)
router.put('/entries/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const {
      present_days,
      gross_salary_rate,
      special_allowance,
      thermal_allowance,
      perf_allowance_monthly,
      bonus,
      employee_epf_12,
      employee_esi_075,
      employee_lwf,
      employer_epf_12,
      employer_epf_1,
      employer_esi_325,
      employer_lwf
    } = req.body;

    // Fetch existing entry
    const entryRes = await db.query(`
      SELECT pe.*, p.total_days, p.status as period_status, d.alias as designation_alias,
             e.name as emp_name
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      WHERE pe.id = $1;
    `, [Number(id)]);

    if (entryRes.rows.length === 0) return res.status(404).json({ error: 'Payroll entry not found' });
    const existing = entryRes.rows[0];

    if (existing.period_status === 'Finalized' && req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    // Fetch active rule set
    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    const totalDays = Number(existing.total_days) || 30;
    const newPresentDays = present_days !== undefined ? Number(present_days) : Number(existing.present_days);
    const newGrossRate = gross_salary_rate !== undefined ? Number(gross_salary_rate) : Number(existing.gross_salary_rate);
    const newSpecialAllowance = special_allowance !== undefined ? Number(special_allowance) : Number(existing.special_allowance);
    const newPerfMonthly = perf_allowance_monthly !== undefined ? Number(perf_allowance_monthly) : Number(existing.perf_allowance_monthly);
    const newBonus = bonus !== undefined ? Number(bonus) : Number(existing.bonus);

    // Calculate with any explicit custom values
    const calc = calculatePayroll({
      designationAlias: existing.designation_alias || 'SW',
      grossSalaryRate: newGrossRate,
      specialAllowanceRate: newSpecialAllowance,
      totalDays,
      presentDays: newPresentDays,
      perfAllowanceMonthly: newPerfMonthly,
      bonus: newBonus,
      customThermalAllowance: thermal_allowance !== undefined ? Number(thermal_allowance) : undefined,
      customEmployeeEpf: employee_epf_12 !== undefined ? Number(employee_epf_12) : undefined,
      customEmployeeEsi: employee_esi_075 !== undefined ? Number(employee_esi_075) : undefined,
      customEmployeeLwf: employee_lwf !== undefined ? Number(employee_lwf) : undefined,
      customEmployerEpf: employer_epf_12 !== undefined ? Number(employer_epf_12) : undefined,
      customEmployerEpf1: employer_epf_1 !== undefined ? Number(employer_epf_1) : undefined,
      customEmployerEsi: employer_esi_325 !== undefined ? Number(employer_esi_325) : undefined,
      customEmployerLwf: employer_lwf !== undefined ? Number(employer_lwf) : undefined,
      ruleSet: activeRule ? {
        epfWageCap: Number(activeRule.epf_wage_cap),
        epfEmployerRate: Number(activeRule.epf_employer_rate),
        epfMaxCap: Number(activeRule.epf_max_cap),
        epfAdminRate: Number(activeRule.epf_admin_rate),
        epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
        epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
        esiThreshold: Number(activeRule.esi_threshold),
        esiEmployerRate: Number(activeRule.esi_employer_rate),
        esiEmployeeRate: Number(activeRule.esi_employee_rate),
        employerLwf: Number(activeRule.employer_lwf),
        employeeLwf: Number(activeRule.employee_lwf),
        thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
      } : undefined
    });

    const isCustomized = (
      thermal_allowance !== undefined || employee_epf_12 !== undefined ||
      employee_esi_075 !== undefined || employee_lwf !== undefined ||
      employer_epf_12 !== undefined || employer_esi_325 !== undefined
    );

    const updRes = await db.query(`
      UPDATE payroll_entries SET
        present_days = $1,
        gross_salary_rate = $2,
        proportioned_salary = $3,
        special_allowance = $4,
        total_basic = $5,
        thermal_allowance = $6,
        perf_allowance_monthly = $7,
        perf_allowance_days = $8,
        total_earnings_before_bonus = $9,
        bonus = $10,
        employer_epf_12 = $11,
        employer_epf_1 = $12,
        employer_esi_325 = $13,
        employer_lwf = $14,
        gross_total = $15,
        employee_epf_12 = $16,
        employee_esi_075 = $17,
        employee_lwf = $18,
        total_employee_deductions = $19,
        total_employer_contributions = $20,
        combined_deductions = $21,
        net_payable = $22,
        is_overridden = $23,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $24
      RETURNING *;
    `, [
      newPresentDays, newGrossRate, calc.proportionedSalary, newSpecialAllowance,
      calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
      calc.totalEarningsBeforeBonus, newBonus, calc.employerEpf12, calc.employerEpf1,
      calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
      calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
      calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
      isCustomized || existing.is_overridden, Number(id)
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_PAYROLL_ENTRY', 'PAYROLL_ENTRY', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Updated components for ${existing.emp_name}. Net payable: ₹${calc.netPayable}`]);

    res.json({ entry: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/attendance/batch (Batch update employee days)
router.post('/attendance/batch', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { periodId, days, employeeIds } = req.body;
    if (!periodId || days === undefined || Number(days) < 0) {
      return res.status(400).json({ error: 'periodId and valid days are required' });
    }

    let query = `
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as curr_gross, dsr.special_allowance as curr_special
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1
    `;
    const params: any[] = [Number(periodId)];

    if (Array.isArray(employeeIds) && employeeIds.length > 0) {
      query += ` AND pe.employee_id = ANY($2)`;
      params.push(employeeIds);
    }

    const rows = await db.query(query, params);

    // Fetch active rules
    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    let count = 0;
    for (const r of rows.rows) {
      const calc = calculatePayroll({
        designationAlias: r.designation_alias || 'SW',
        grossSalaryRate: Number(r.curr_gross || r.gross_salary_rate),
        specialAllowanceRate: Number(r.curr_special || r.special_allowance),
        totalDays: Number(r.total_days),
        presentDays: Number(days),
        perfAllowanceMonthly: Number(r.perf_allowance_monthly),
        bonus: Number(r.bonus),
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          proportioned_salary = $2,
          total_basic = $3,
          thermal_allowance = $4,
          perf_allowance_days = $5,
          total_earnings_before_bonus = $6,
          employer_epf_12 = $7,
          employer_epf_1 = $8,
          employer_esi_325 = $9,
          gross_total = $10,
          employee_epf_12 = $11,
          employee_esi_075 = $12,
          total_employee_deductions = $13,
          total_employer_contributions = $14,
          combined_deductions = $15,
          net_payable = $16,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $17;
      `, [
        Number(days), calc.proportionedSalary, calc.totalBasic, calc.thermalAllowance,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable, r.id
      ]);
      count++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'BATCH_ATTENDANCE_UPDATE', 'PAYROLL_PERIOD', $2, $3);
    `, [req.user?.username || 'admin', String(periodId), `Batch updated attendance to ${days} days for ${count} employees`]);

    res.json({ message: `Attendance updated for ${count} employees`, count });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/batch-update (Multi-edit all allowances, performance, rates in 1 click)
router.post('/batch-update', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const {
      periodId,
      entryIds,
      designationId,
      contractorId,
      updates = {}
    } = req.body;

    if (!periodId) return res.status(400).json({ error: 'periodId is required' });

    const periodRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
    if (periodRes.rows.length === 0) return res.status(404).json({ error: 'Period not found' });
    const period = periodRes.rows[0];

    if (period.status === 'Finalized' && req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    let query = `
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as std_gross, dsr.special_allowance as std_special, dsr.perf_allowance_default as std_perf
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1
    `;
    const params: any[] = [Number(periodId)];
    let pIdx = 2;

    if (Array.isArray(entryIds) && entryIds.length > 0) {
      query += ` AND pe.id = ANY($${pIdx++})`;
      params.push(entryIds);
    } else {
      if (designationId) {
        query += ` AND e.designation_id = $${pIdx++}`;
        params.push(Number(designationId));
      }
      if (contractorId) {
        query += ` AND e.contractor_id = $${pIdx++}`;
        params.push(Number(contractorId));
      }
    }

    const rowsRes = await db.query(query, params);
    if (rowsRes.rows.length === 0) {
      return res.json({ message: 'No entries matched the criteria', updatedCount: 0 });
    }

    let updatedCount = 0;
    for (const r of rowsRes.rows) {
      const totalDays = Number(r.total_days) || 30;

      let newGrossRate = Number(r.gross_salary_rate);
      let newSpecialAllowance = Number(r.special_allowance);
      let newPerfMonthly = Number(r.perf_allowance_monthly);
      let newBonus = Number(r.bonus);
      let newPresentDays = Number(r.present_days);
      let customThermal: number | undefined = undefined;

      if (updates.resetToDesignationDefaults) {
        newGrossRate = r.std_gross !== null ? Number(r.std_gross) : Number(r.gross_salary_rate);
        newSpecialAllowance = r.std_special !== null ? Number(r.std_special) : Number(r.special_allowance);
        newPerfMonthly = r.std_perf !== null ? Number(r.std_perf) : 225;
        customThermal = undefined;
      } else {
        if (updates.gross_salary_rate !== undefined && updates.gross_salary_rate !== null && updates.gross_salary_rate !== '') {
          newGrossRate = Number(updates.gross_salary_rate);
        }
        if (updates.special_allowance !== undefined && updates.special_allowance !== null && updates.special_allowance !== '') {
          newSpecialAllowance = Number(updates.special_allowance);
        }
        if (updates.perf_allowance_monthly !== undefined && updates.perf_allowance_monthly !== null && updates.perf_allowance_monthly !== '') {
          newPerfMonthly = Number(updates.perf_allowance_monthly);
        }
        if (updates.bonus !== undefined && updates.bonus !== null && updates.bonus !== '') {
          newBonus = Number(updates.bonus);
        }
        if (updates.present_days !== undefined && updates.present_days !== null && updates.present_days !== '') {
          newPresentDays = Number(updates.present_days);
        }
        if (updates.thermal_mode === 'fixed') {
          customThermal = updates.thermal_allowance !== undefined && updates.thermal_allowance !== '' ? Number(updates.thermal_allowance) : 1500;
        } else if (updates.thermal_mode === 'custom') {
          customThermal = Number(updates.thermal_allowance);
        } else if (updates.thermal_mode === 'auto') {
          customThermal = undefined;
        } else if (updates.thermal_allowance !== undefined && updates.thermal_allowance !== '') {
          customThermal = Number(updates.thermal_allowance);
        } else {
          customThermal = r.thermal_allowance !== null ? Number(r.thermal_allowance) : undefined;
        }
      }

      const calc = calculatePayroll({
        designationAlias: r.designation_alias || 'SW',
        grossSalaryRate: newGrossRate,
        specialAllowanceRate: newSpecialAllowance,
        totalDays,
        presentDays: newPresentDays,
        perfAllowanceMonthly: newPerfMonthly,
        bonus: newBonus,
        customThermalAllowance: customThermal,
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          gross_salary_rate = $2,
          proportioned_salary = $3,
          special_allowance = $4,
          total_basic = $5,
          thermal_allowance = $6,
          perf_allowance_monthly = $7,
          perf_allowance_days = $8,
          total_earnings_before_bonus = $9,
          bonus = $10,
          employer_epf_12 = $11,
          employer_epf_1 = $12,
          employer_esi_325 = $13,
          employer_lwf = $14,
          gross_total = $15,
          employee_epf_12 = $16,
          employee_esi_075 = $17,
          employee_lwf = $18,
          total_employee_deductions = $19,
          total_employer_contributions = $20,
          combined_deductions = $21,
          net_payable = $22,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $23;
      `, [
        newPresentDays, newGrossRate, calc.proportionedSalary, newSpecialAllowance,
        calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, newBonus, calc.employerEpf12, calc.employerEpf1,
        calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
        r.id
      ]);
      updatedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'BULK_UPDATE_ALLOWANCES_RATES', 'PAYROLL_PERIOD', $2, $3);
    `, [req.user?.username || 'admin', String(periodId), `Bulk updated allowances and rates for ${updatedCount} employees`]);

    res.json({ message: `Successfully updated ${updatedCount} employees in 1-click`, updatedCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/batch-save-grid (Save multiple rows edited in spreadsheet mode in 1-click)
router.post('/batch-save-grid', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { periodId, rows } = req.body;
    if (!periodId || !Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'periodId and rows array are required' });
    }

    const periodRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
    if (periodRes.rows.length === 0) return res.status(404).json({ error: 'Period not found' });
    const period = periodRes.rows[0];

    if (period.status === 'Finalized' && req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    let savedCount = 0;
    for (const r of rows) {
      if (!r.id) continue;
      const entryRes = await db.query(`
        SELECT pe.*, p.total_days, d.alias as designation_alias
        FROM payroll_entries pe
        JOIN payroll_periods p ON pe.payroll_period_id = p.id
        JOIN employees e ON pe.employee_id = e.id
        LEFT JOIN designations d ON e.designation_id = d.id
        WHERE pe.id = $1 AND pe.payroll_period_id = $2;
      `, [Number(r.id), Number(periodId)]);

      if (entryRes.rows.length === 0) continue;
      const existing = entryRes.rows[0];
      const totalDays = Number(existing.total_days) || 30;

      const newPresentDays = r.present_days !== undefined ? Number(r.present_days) : Number(existing.present_days);
      const newGrossRate = r.gross_salary_rate !== undefined ? Number(r.gross_salary_rate) : Number(existing.gross_salary_rate);
      const newSpecial = r.special_allowance !== undefined ? Number(r.special_allowance) : Number(existing.special_allowance);
      const newThermal = r.thermal_allowance !== undefined ? Number(r.thermal_allowance) : Number(existing.thermal_allowance);
      const newPerfMonthly = r.perf_allowance_monthly !== undefined ? Number(r.perf_allowance_monthly) : Number(existing.perf_allowance_monthly);
      const newBonus = r.bonus !== undefined ? Number(r.bonus) : Number(existing.bonus);

      const calc = calculatePayroll({
        designationAlias: existing.designation_alias || 'SW',
        grossSalaryRate: newGrossRate,
        specialAllowanceRate: newSpecial,
        totalDays,
        presentDays: newPresentDays,
        perfAllowanceMonthly: newPerfMonthly,
        bonus: newBonus,
        customThermalAllowance: newThermal,
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          gross_salary_rate = $2,
          proportioned_salary = $3,
          special_allowance = $4,
          total_basic = $5,
          thermal_allowance = $6,
          perf_allowance_monthly = $7,
          perf_allowance_days = $8,
          total_earnings_before_bonus = $9,
          bonus = $10,
          employer_epf_12 = $11,
          employer_epf_1 = $12,
          employer_esi_325 = $13,
          employer_lwf = $14,
          gross_total = $15,
          employee_epf_12 = $16,
          employee_esi_075 = $17,
          employee_lwf = $18,
          total_employee_deductions = $19,
          total_employer_contributions = $20,
          combined_deductions = $21,
          net_payable = $22,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $23;
      `, [
        newPresentDays, newGrossRate, calc.proportionedSalary, newSpecial,
        calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, newBonus, calc.employerEpf12, calc.employerEpf1,
        calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
        r.id
      ]);
      savedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'GRID_SAVE_ALLOWANCES_RATES', 'PAYROLL_PERIOD', $2, $3);
    `, [req.user?.username || 'admin', String(periodId), `Grid saved allowances and rates for ${savedCount} entries in 1 click`]);

    res.json({ message: `Saved changes for ${savedCount} entries in 1-click`, savedCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/entries/:id/override (Manual field override)
router.post('/entries/:id/override', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { fieldName, overrideValue, reason } = req.body;
    if (!fieldName || overrideValue === undefined || !reason) {
      return res.status(400).json({ error: 'fieldName, overrideValue, and reason are required' });
    }

    const curRes = await db.query(`SELECT * FROM payroll_entries WHERE id = $1;`, [Number(id)]);
    if (curRes.rows.length === 0) return res.status(404).json({ error: 'Payroll entry not found' });
    const cur = curRes.rows[0];

    const originalValue = cur[fieldName];
    const validFields = [
      'gross_salary_rate', 'special_allowance', 'thermal_allowance', 'bonus',
      'employee_epf_12', 'employee_esi_075', 'employee_lwf', 'net_payable'
    ];
    if (!validFields.includes(fieldName)) {
      return res.status(400).json({ error: `Field "${fieldName}" cannot be manually overridden.` });
    }

    await db.query(`
      UPDATE payroll_entries SET ${fieldName} = $1, is_overridden = TRUE, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2;
    `, [Number(overrideValue), Number(id)]);

    await db.query(`
      INSERT INTO payroll_overrides (payroll_entry_id, field_name, original_value, override_value, reason, user_name)
      VALUES ($1, $2, $3, $4, $5, $6);
    `, [Number(id), fieldName, Number(originalValue) || 0, Number(overrideValue), reason, req.user?.username || 'admin']);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'OVERRIDE_PAYROLL_FIELD', 'PAYROLL_ENTRY', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Overrode ${fieldName} to ₹${overrideValue}. Reason: ${reason}`]);

    const updated = await db.query(`SELECT * FROM payroll_entries WHERE id = $1;`, [Number(id)]);
    res.json({ entry: updated.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods/:id/status (Workflow state machine)
router.post('/periods/:id/status', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { status, justification } = req.body;
    const allowed = ['Draft', 'Calculated', 'Under Review', 'Approved', 'Finalized', 'Reopened'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Allowed: ${allowed.join(', ')}` });
    }

    if (status === 'Finalized' && req.user?.role !== 'Super Administrator' && req.user?.role !== 'Payroll Administrator') {
      return res.status(403).json({ error: 'Only Administrators can finalize payroll' });
    }

    let query = `UPDATE payroll_periods SET status = $1`;
    const params: any[] = [status === 'Reopened' ? 'Draft' : status];

    if (status === 'Finalized') {
      query += `, finalized_at = CURRENT_TIMESTAMP`;
    }

    query += ` WHERE id = $2 RETURNING *;`;
    params.push(Number(id));

    const result = await db.query(query, params);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Payroll period not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_PERIOD_STATUS', 'PAYROLL_PERIOD', $2, $3);
    `, [req.user?.username || 'admin', String(id), `Status changed to ${status}. ${justification ? `Notes: ${justification}` : ''}`]);

    res.json({ period: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/recalculate-all
router.post('/recalculate-all', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { periodId } = req.body;
    if (!periodId) return res.status(400).json({ error: 'periodId is required' });

    // Fetch active rule set
    const ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    const entriesRes = await db.query(`
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as curr_gross, dsr.special_allowance as curr_special
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1;
    `, [Number(periodId)]);

    let count = 0;
    for (const row of entriesRes.rows) {
      const calc = calculatePayroll({
        designationAlias: row.designation_alias || 'SW',
        grossSalaryRate: row.curr_gross !== null ? Number(row.curr_gross) : Number(row.gross_salary_rate),
        specialAllowanceRate: row.curr_special !== null ? Number(row.curr_special) : Number(row.special_allowance),
        totalDays: Number(row.total_days),
        presentDays: Number(row.present_days),
        perfAllowanceMonthly: Number(row.perf_allowance_monthly),
        bonus: Number(row.bonus),
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          proportioned_salary = $1,
          total_basic = $2,
          thermal_allowance = $3,
          perf_allowance_days = $4,
          total_earnings_before_bonus = $5,
          employer_epf_12 = $6,
          employer_epf_1 = $7,
          employer_esi_325 = $8,
          gross_total = $9,
          employee_epf_12 = $10,
          employee_esi_075 = $11,
          total_employee_deductions = $12,
          total_employer_contributions = $13,
          combined_deductions = $14,
          net_payable = $15,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $16;
      `, [
        calc.proportionedSalary, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, calc.employerEpf12, calc.employerEpf1, calc.employerEsi325,
        calc.grossTotal, calc.employeeEpf12, calc.employeeEsi075, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable, row.id
      ]);
      count++;
    }

    res.json({ message: `Successfully recalculated ${count} entries with active rules` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
