import { Router } from 'express';
import path from 'path';
import XLSX from 'xlsx';
import { calculatePayroll } from '../engine/payrollCalculator';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();

router.get('/run', authMiddleware, async (req, res) => {
  try {
    const filePath = path.join(__dirname, '../../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
    const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

    const results: any = {
      timestamp: new Date().toISOString(),
      referenceFile: 'SALARY SHEET-for EPF Sepf 2026.xlsx',
      sheets: {}
    };

    let grandTotalChecked = 0;
    let grandTotalMatched = 0;

    // 1. Verify MM-1
    {
      const sheet = workbook.Sheets['MM-1'];
      const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
      const comparisons: any[] = [];
      let checked = 0;
      let matched = 0;

      for (let r = 1; r <= 21; r++) {
        const getVal = (c: number) => {
          const cell = sheet[XLSX.utils.encode_cell({ r, c })];
          return cell ? cell.v : null;
        };

        const empCode = String(getVal(0) || '');
        const empName = String(getVal(1) || '');
        const desig = String(getVal(4) || '');
        const totalDays = Number(getVal(25)) || 30;
        const presentDays = Number(getVal(26)) || 0;
        const perfMonthly = Number(getVal(32)) || 0;
        const bonus = Number(getVal(35)) || 0;

        const isPerfRounded = r >= 16;
        const calc = calculatePayroll({
          designationAlias: desig,
          totalDays,
          presentDays,
          perfAllowanceMonthly: perfMonthly,
          bonus,
          isPerfRounded
        });

        checked++;
        grandTotalChecked++;

        const sheetNet = Number(getVal(47));
        const sheetGrossTotal = Number(getVal(40));
        const sheetBasic = Number(getVal(30));
        const sheetThermal = Number(getVal(31));
        const sheetEmpEpf = Number(getVal(36));
        const sheetEmpEsi = Number(getVal(38));

        const isMatch = Math.abs(calc.netPayable - sheetNet) < 0.01;
        if (isMatch) {
          matched++;
          grandTotalMatched++;
        }

        comparisons.push({
          row: r + 1,
          empCode,
          empName,
          designation: desig,
          attendance: `${presentDays}/${totalDays}`,
          softwareNetPayable: calc.netPayable,
          excelNetPayable: sheetNet,
          diff: Math.round((calc.netPayable - sheetNet) * 100) / 100,
          status: isMatch ? 'MATCH' : 'MISMATCH',
          breakdown: {
            totalBasic: { soft: calc.totalBasic, excel: sheetBasic },
            thermalAllowance: { soft: calc.thermalAllowance, excel: sheetThermal },
            employerEpf12: { soft: calc.employerEpf12, excel: sheetEmpEpf },
            employerEsi325: { soft: calc.employerEsi325, excel: sheetEmpEsi },
            grossTotal: { soft: calc.grossTotal, excel: sheetGrossTotal }
          }
        });
      }

      results.sheets['MM-1'] = {
        totalChecked: checked,
        totalMatched: matched,
        mismatches: checked - matched,
        matchRate: `${((matched / checked) * 100).toFixed(1)}%`,
        sampleComparisons: comparisons
      };
    }

    // 2. Verify EMC
    {
      const sheet = workbook.Sheets['EMC'];
      const comparisons: any[] = [];
      let checked = 0;
      let matched = 0;

      for (let r = 2; r <= 46; r++) {
        const getVal = (c: number) => {
          const cell = sheet[XLSX.utils.encode_cell({ r, c })];
          return cell ? cell.v : null;
        };

        const srNo = String(getVal(0) || '');
        const refNo = String(getVal(1) || '');
        const empCode = `EMC-${refNo || srNo}`;
        const empName = String(getVal(4) || '');
        const desig = String(getVal(7) || '');
        const totalDays = Number(getVal(28)) || 30;
        const presentDays = Number(getVal(29)) || 0;
        const perfMonthly = Number(getVal(35)) || 0;
        const bonus = Number(getVal(38)) || 0;

        const calc = calculatePayroll({
          designationAlias: desig,
          totalDays,
          presentDays,
          perfAllowanceMonthly: perfMonthly,
          bonus,
          isPerfRounded: false
        });

        checked++;
        grandTotalChecked++;

        const sheetNet = Number(getVal(50));
        const sheetGrossTotal = Number(getVal(43));
        const sheetBasic = Number(getVal(33));
        const sheetThermal = Number(getVal(34));
        const sheetEmpEpf = Number(getVal(39));
        const sheetEmpEsi = Number(getVal(41));

        const isMatch = Math.abs(calc.netPayable - sheetNet) < 0.01;
        if (isMatch) {
          matched++;
          grandTotalMatched++;
        }

        comparisons.push({
          row: r + 1,
          empCode,
          empName,
          designation: desig,
          attendance: `${presentDays}/${totalDays}`,
          softwareNetPayable: calc.netPayable,
          excelNetPayable: sheetNet,
          diff: Math.round((calc.netPayable - sheetNet) * 100) / 100,
          status: isMatch ? 'MATCH' : 'MISMATCH',
          breakdown: {
            totalBasic: { soft: calc.totalBasic, excel: sheetBasic },
            thermalAllowance: { soft: calc.thermalAllowance, excel: sheetThermal },
            employerEpf12: { soft: calc.employerEpf12, excel: sheetEmpEpf },
            employerEsi325: { soft: calc.employerEsi325, excel: sheetEmpEsi },
            grossTotal: { soft: calc.grossTotal, excel: sheetGrossTotal }
          }
        });
      }

      results.sheets['EMC'] = {
        totalChecked: checked,
        totalMatched: matched,
        mismatches: checked - matched,
        matchRate: `${((matched / checked) * 100).toFixed(1)}%`,
        sampleComparisons: comparisons
      };
    }

    results.overall = {
      totalEmployeesAudited: grandTotalChecked,
      totalEmployeesMatched: grandTotalMatched,
      overallMatchRate: `${((grandTotalMatched / grandTotalChecked) * 100).toFixed(2)}%`,
      status: grandTotalChecked === grandTotalMatched ? '100% RECONCILED AND VERIFIED' : 'DISCREPANCIES DETECTED'
    };

    res.json(results);
  } catch (err: any) {
    console.error('Reconciliation error:', err);
    res.status(500).json({ error: err.message || 'Failed to run reconciliation' });
  }
});

export default router;
