import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// GET /api/users
router.get('/', authMiddleware, async (req, res) => {
  try {
    const result = await db.query(`
      SELECT id, username, full_name, role, is_active, created_at, updated_at
      FROM users
      ORDER BY id ASC;
    `);
    res.json({ users: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/users
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Only Super Administrators can create users' });
    }

    const { username, password, fullName, role } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'Username, password, and full name are required' });
    }

    const check = await db.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1);', [username.trim()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Username "${username.trim()}" is already taken.` });
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);

    const result = await db.query(`
      INSERT INTO users (username, password_hash, full_name, role)
      VALUES ($1, $2, $3, $4)
      RETURNING id, username, full_name, role, is_active, created_at;
    `, [username.trim(), hash, fullName.trim(), role || 'Payroll Operator']);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'CREATE_USER', 'USER', $2, $3);
    `, [req.user.username, String(result.rows[0].id), `Created user ${username} (${role})`]);

    res.status(201).json({ user: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/users/:id
router.put('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Only Super Administrators can update users' });
    }

    const { id } = req.params;
    const { username, fullName, role, isActive, password } = req.body;

    if (username) {
      const check = await db.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1) AND id != $2;', [username.trim(), Number(id)]);
      if (check.rows.length > 0) {
        return res.status(409).json({ error: `Username "${username.trim()}" is already taken by another account.` });
      }
    }

    let query = `UPDATE users SET full_name = COALESCE($1, full_name), role = COALESCE($2, role), is_active = COALESCE($3, is_active)`;
    const params: any[] = [fullName || null, role || null, isActive !== undefined ? isActive : null];
    let idx = 4;

    if (username) {
      query += `, username = $${idx++}`;
      params.push(username.trim());
    }

    if (password && password.trim()) {
      const salt = bcrypt.genSaltSync(10);
      const hash = bcrypt.hashSync(password.trim(), salt);
      query += `, password_hash = $${idx++}`;
      params.push(hash);
    }

    query += `, updated_at = CURRENT_TIMESTAMP WHERE id = $${idx++} RETURNING id, username, full_name, role, is_active, updated_at;`;
    params.push(Number(id));

    const result = await db.query(query, params);
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_USER', 'USER', $2, $3);
    `, [req.user.username, String(id), `Updated user ${result.rows[0].username} details/role`]);

    res.json({ user: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/users/:id
router.delete('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Only Super Administrators can delete users' });
    }

    const { id } = req.params;
    const targetId = Number(id);

    // Safeguard: Cannot delete yourself
    if (req.user.id === targetId) {
      return res.status(400).json({ error: 'You cannot delete your own active administrator account while logged in.' });
    }

    // Safeguard: Cannot delete if it is the only Super Administrator
    const userToDel = await db.query('SELECT role, username FROM users WHERE id = $1;', [targetId]);
    if (userToDel.rows.length === 0) return res.status(404).json({ error: 'User not found' });

    if (userToDel.rows[0].role === 'Super Administrator') {
      const superCount = await db.query("SELECT COUNT(*) as count FROM users WHERE role = 'Super Administrator' AND is_active = TRUE;");
      if (parseInt(superCount.rows[0].count, 10) <= 1) {
        return res.status(400).json({ error: 'Cannot delete the only remaining active Super Administrator.' });
      }
    }

    const delRes = await db.query('DELETE FROM users WHERE id = $1 RETURNING id, username, full_name, role;', [targetId]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DELETE_USER', 'USER', $2, $3);
    `, [req.user.username, String(targetId), `Deleted user ${delRes.rows[0].username} (${delRes.rows[0].role})`]);

    res.json({ message: 'User deleted successfully', user: delRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
