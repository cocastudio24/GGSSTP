@echo off
title GGSSTP Payroll Management System
echo ================================================================
echo Starting GGSSTP Payroll System (Guru Gobind Singh ST Plant)
echo ================================================================
echo.

cd /d "%~dp0"

echo Checking Node.js installation...
node -v >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please install Node.js v18 or v20 LTS from https://nodejs.org/
    pause
    exit /b 1
)

echo.
echo Launching Server on port 5000...
echo.
echo Local Computer:    http://localhost:5000
echo Network Access:    http://192.168.1.6:5000
echo.
echo Press Ctrl+C in this window to stop the server.
echo ================================================================
echo.

node dist/server.js
pause
